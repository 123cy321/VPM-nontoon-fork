# SelfLight —— 角色「自己的光源 + 自阴影」

给 avatar 一路**只照自己**的光，并让它给自己投影。

## 为什么不挂真实的 Unity Light（有官方出处）

| 事实 | 出处 |
| --- | --- |
| VRChat 性能等级里 **Lights 在 PC 上 Excellent / Good / Medium 都要求 0**，只有 Poor 允许 1 —— 挂一盏实时光直接掉档 | [Performance Ranks](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/) |
| 真实光会**照亮周围世界与其他玩家**，做不到"只照自己"。VRChat 的层是固定的：`Player(9)` 是"除本地玩家以外的玩家"，`PlayerLocal(10)` 才是本地玩家 | [Unity Layers in VRChat](https://creators.vrchat.com/worlds/layers/) |
| Unity 的 light culling mask 对自定义层本来就不可靠，而且 Quest 端实时光基本不可用 | Unity 社区结论 |

所以本功能**不产生任何 Light**：全部在着色器里完成 ⇒ 不进 VRChat 的 Lights 计数、不外溢、Quest 也能用。

## 它是怎么工作的

1. **私有光**（`Shaders/Modules/SelfLight/phase_customlight.hlsl`）：
   在 `customlight` 阶段往 `lightSum` 里加一路由材质参数定义的光（方向 / 颜色 / 强度）。
   - `Only This Light` 打开时，**丢掉世界光与环境光**并把 Shade ramp 的方向也换成它 ——
     avatar 在任何世界里长得都一样。
   - 运行时开销：1 次 `dot(N, L)`。
2. **自阴影**：一张**光照空间的正交深度图**。像素里 `worldPos` 投到光源空间后与贴图比较，
   多 1 次贴图采样 + 几个点乘。
   - 烘焙由 **`NTSelfLight` 组件**在编辑器里完成（纯 CPU 光线投射，**不需要相机 / RenderTexture / GPU**）。
3. **写入材质**：所有参数（含阴影贴图的基与范围）都写进材质属性。
   组件**运行时没有任何行为** ⇒ 烘焙完可以把它删掉，运行时零额外负担。

## 怎么用

1. 在 avatar 根节点上 **Add Component → NonToon → Self Light**。
2. `Light Source` 指定你要的那盏光源（**只读它的方向/颜色**，不会真的把它挂上去）。
3. 需要的话打开 `Only This Light`（只由它照亮）。
4. 点 **「烘焙自阴影并写入材质」**。会：
   - 采集该层级下所有 `MeshRenderer` / `SkinnedMeshRenderer`（蒙皮的按**当前姿态** `BakeMesh`）；
   - 用 `HideAndDontSave` 的临时 `MeshCollider` 逐像素朝光源方向投射射线，记录最近命中距离；
   - 写出 `Assets/NonToonSelfLight/SelfShadow_*.png`（关闭 sRGB / 压缩 / mipmap，否则深度会被改坏）；
   - 把方向、基、范围、强度、偏移写进该层级里所有带 `_UseSelfLight` 的材质。
5. 想只更新参数（不重新烘焙）就点 **「只同步光源参数」**。

## ⚠️ 注意事项

1. **渲染跟随姿态** —— 阴影是**烘焙那一刻的姿态**。换了姿势、改了网格、改了光源方向，都要**重新烘焙**。
   （VRChat 里 avatar 的姿势千变万化，所以自阴影适合"变化不大"的部位：头发的投影、脸部的立体感等。）
2. **只写进材质** —— 材质是共享资源；如果同一材质被多个 avatar/对象引用，它们会共享同一份烘焙结果。
   需要各自独立就复制一份材质。
3. **本组件运行时无行为**，烘焙后删除即可；删了也能正常显示（数据在材质里）。
4. **分辨率与耗时**：256³（默认）足够，512 更细腻但射线数 ×4；烘焙是 CPU 的，几十万条射线量级，
   大 avatar 请耐心等几秒。
5. **阴影痤疮**（表面出现条纹噪点）→ 调大 `Shadow Bias`；**漏光**（本该有阴影处发亮）→ 调大分辨率或检查光源方向。
6. **贴图必须保持** 关闭 sRGB / 不压缩 / 无 mipmap —— 这是深度数据，不是颜色。烘焙器已自动设置，
   但不要手动改 Importer。
7. **需要 NonToon (Fork) ≥ 0.2.0**（`SelfLight` 模块是 0.2.0 新增的）。
8. **和世界光的关系**：不开 `Only This Light` 时，世界光/环境光**照旧**影响 avatar，这一路光只是**额外加上去**的；
   想要"完全由它决定"就打开那个开关（代价：avatar 不再随世界变化，夜里也依然亮）。
9. **它不是阴影投射器** —— 别的物体（世界、其他玩家）**不会**被这盏光投影。这是"只照自己"的另一面。
10. **性能**：运行时不增加光照计算量，只是每像素多 1 次贴图采样 + 1 个 dot（`Only This Light` 打开时反而更省：
    世界光被丢弃了）。

---

## v2（NonToon Fork 0.3.0 / 工具包 0.4.0）：类 PCSS 软阴影

参考 **nHaruka 的 PCSS4VRC「真实影システム」**（<https://github.com/nHaruka-git/PCSS4VRC>，
PCSS 算法本身参考 <https://github.com/TheMasonX/UnityPCSS>）的思路，但把"挂一盏实时光"换成
**着色器侧**的实现，所以在 VRChat 里的代价完全不同：

| | PCSS4VRC（真实影システム） | 本分支 SelfLight v2 |
|---|---|---|
| 手段 | 真·Spot Light（+ 自定义 lilToon/Poiyomi 着色器） | 私有光 + 烘焙深度图，**没有 Light 组件** |
| VRChat 性能等级 | Lights = 1 → PC 上最高只能到 **Poor** | Lights 保持 **0**，不拖累等级 |
| 影响他人/世界 | 会照亮周围（因此需要遮罩/开关去压） | **完全不会**外溢 |
| Quest | 官方说明**不支持** | 可用（固定采样、无动态循环） |
| 费用 | 付费资产 | 免费（本仓库） |
| 软阴影 | PCSS | PCSS（同样先 blocker search 再变半径 PCF） |

### 新增的材质属性（SelfLight 模块）

| 属性 | 说明 |
|---|---|
| `PCSS Soft Shadow` | 开 = 8 次 blocker search + 12 次变半径 PCF；关 = 1 次采样的硬阴影（最省） |
| `Softness` | 半影大小（柔度），只在 PCSS 开时有效 |
| `Shadow Density` | 阴影浓度：1 = 该黑就黑，0 = 完全没有自阴影 |
| `Shadow Clamp` | 把 PCSS 的软边**压成硬边**（动画风），0 = 保持软边 |
| `Shadow Distance` | 离相机超过该距离**自动关闭**自阴影（PCSS4VRC 默认也是 10m）；0 = 不限制 |
| `Receive Mask` + 通道 + 强度 | 逐像素控制"哪里接收阴影"（对应 PCSS4VRC 的 **ReceiveMask**），白色 = 正常接收 |
| `Shadow Texels` | 深度图分辨率，PCSS 用它换算一个纹素的大小（组件会自动写入） |

### 采样预算（我们自己定的上限，参考 PCSS4VRC 的建议值）

- 官方建议：`Test Samplers ≤ 12`、`Filter Samplers ≤ 24`。
- 本实现：blocker **8** + filter **12** = 20 次，**固定循环**（`[unroll]`，无动态分支长度），在预算内。
- 只有 `_UseSelfLight` 打开 **且** 像素落在光源包围盒内 **且** 在 `Shadow Distance` 之内才采样，
  否则一次都不采。PCSS 关掉时退化成 1 次采样。

### 还没做的（诚实说明）

- **CastMask**（遮住"不投影的部件"，如眼白周围的刘海）没做 —— 我们的深度图是在**烘焙时**由 CPU 光栅化生成的，
  要做到"按遮罩跳过遮挡物"就得在烘焙器里逐像素查被遮挡物的遮罩，成本与精度都不划算。
  替代做法：把不想投影的部件**排除出烘焙**（组件烘焙时只传需要的 Renderer），或直接调小 `Shadow Distance`。
- **实时性**：仍然是"烘焙那一刻的姿态"。VRChat 内做不到实时自阴影（avatar 不能带相机/RT，实时光又会掉性能等级）。
- `_ShadowAOShift` 之类 lilToon 专属的边界遮罩重映射没有对应项。

---

## v3（0.3.1 / 0.4.1）：性能不是约束之后放开的两件事

前提变了：**性能等级无所谓**（avatar 本来就是极高负载）。于是把之前主动放弃的两件事拿回来。

### 3.1 PCSS 画质档位

| 档位 | Blocker | PCF | 合计 |
|---|---|---|---|
| 低 | 8 | 12 | 20 |
| 中（默认） | 12 | 24 | 36 |
| 高 | 20 | 40 | 60 |
| 极高 | 32 | 64 | 96 |

- 材质属性 `_SelfLightPCSSQuality`，组件面板上是「PCSS 画质档位」下拉。
- 烘焙分辨率上限提到 **2048**（4M 条射线，慢，但边缘更干净）。
- 实现细节：深度图采样改成**显式 LOD 0**（`SampleLevel(sampler, uv, 0)`）。
  原来用隐式导数的 `tex2D`，在动态循环里会被编译器抱怨
  `gradient instruction used in a loop with varying iteration` —— 深度图本来不需要 mip，
  改完之后警告消失，也不会因为"unroll 不动"而退化。

### 3.2 实时光源模式（真·实时自阴影）

`Self Light` 组件的 **自阴影来源** 有两个选项；实时光源就是 PCSS4VRC 走的那条路：

| | 烘焙阴影图（默认） | 实时光源 |
|---|---|---|
| 影子 | 烘焙那一刻的姿态 | **实时**，改姿势立刻变，不用烘焙 |
| Lights 计数 | 不占 | **占 1**（PC 上最高 Poor） |
| 别人看得到吗 | 永远可见 | 取决于**观看者**的 Shadow Quality；别人关了阴影就看不到 |
| Quest | 可用 | 基本不可用 |
| 叠加 | 无 | 多盏这种光叠加会把 avatar 照白（PCSS4VRC 的已知问题） |

「创建 / 同步实时光源」会做的事：

1. 建/更新一盏 **Spot Light**（软阴影；角度、范围、颜色、强度、阴影强度都取自组件字段）；
2. **Culling Mask 默认第 10 层 `PlayerLocal`**。VRChat 的层是固定的（`Player(9)` = 其他玩家、
   `PlayerLocal(10)` = 本地玩家），每端只有"自己的 avatar"在 `PlayerLocal` 上 →
   这盏光不会照世界、也不会照其他玩家；
3. 把层级里所有 Renderer 的 **Receive Shadows / Cast Shadows 打开**
   （PCSS4VRC 的 FAQ 专门提过：有些 avatar 默认是关的，关了就不出影子）；
4. 把材质的 `_UseSelfLight` 关掉 —— 否则"真光源 + 着色器私有光"会**双份打光**；
5. Culling Mask 没选 `PlayerLocal`、或照射范围 > 8m 时，面板上给**警告**。

**换模式时的自动收尾**：切到实时光源会禁用已存在的实时光源对象并关掉 `_UseSelfLight`；
切回烘焙会重新打开 `_UseSelfLight` 并写入烘焙参数。

> 其他玩家看到的是什么：光跟着"每端自己的本地玩家"，所以别人看到的是**他们自己**的自阴影效果；
> 你的 avatar 在他们那边由世界光 + 他们自己的光负责。这是这个方案本身的边界（PCSS4VRC 同样如此）。


