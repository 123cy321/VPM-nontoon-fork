# NonToon (Fork) Converter

lilToon → NonToon 材质转换器。作为 **NonToon (Fork)** 的**辅助包**单独分发。

## 为什么单独一个包

- 主着色包 `jp.lilxyzw.nontoon` 保持**纯库**：只有着色器 + 少量编辑器辅助（描边平滑、模块注册、渲染模式），
  不掺工具代码、不掺 VRChat 相关逻辑
- 转换器需要知道 VRChat 的概念（复制 avatar 时剥离 Blueprint ID），这类逻辑只应该待在工具包里
- **本包不依赖 VRChat SDK**：`VRC.Core.PipelineManager` 通过反射访问，
  所以在**非 VRChat 工程**里也能正常编译和使用
- 本包**不引用**主包的程序集（只通过 `Shader.Find` / 材质属性字符串交互），
  因此两边可以各自演进；依赖方向是**转换器 → 着色器**

## 安装

通过 NonToon (Fork) 的 VPM 仓库安装：

```
https://123cy321.github.io/VPM-nontoon-fork/vpm.json
```

它会自动带上 `jp.lilxyzw.nontoon >= 0.1.11`
（**0.1.11 起转换器已从着色包移出**，两边不会重复注册菜单）。

> 反向不成立：装着色包**不会**自动装本包 —— 转换器是可选的工具。

## 用法

**两种用法，任选一种**

1. **拖进去** —— 把模型（Hierarchy 里的，或 Project 里的 fbx / prefab）、材质、文件夹
   拖到窗口**最上面的方框**里，再点「转换拖入的对象」
2. **选中再转** —— 在 Project 或 Hierarchy 里选中，点「转换所选对象」

菜单：`Tools ▸ LilToon to NonToon Converter`
（也可以右键 Hierarchy 里的模型 → `Convert lilToon to NonToon`）

**会发生什么**

- 生成**新的** NonToon 材质，**原 lilToon 材质一个都不动**
- 输出到 `Assets/NonToonConverted/`；报告写到 `Assets/NonToonConverted/LilToonToNonToonReport.txt`，
  并在 `Assets/NonToonConversionLogs/` 留一份带环境信息的日志
- 选 Hierarchy 里的模型时默认会**复制一份** `模型名_NonToon` 并把原对象禁用（`Ctrl+Z` 可撤销）
- 阴影走 NonToon 原生 `ShadowColor` 模块（保真 lilToon 的 border/blur/strength/1st·2nd·3rd）

**转换前先看窗口里「检测到的 lilToon 材质」这个数字**：是 0 就说明拖/选的对象里没有 lilToon 材质
（只认「着色器名里含 lilToon」的材质）。

## 许可

- 原始工具 **LilToonToNonToonConverter 1.1.4** —— MIT 许可，来源 https://vrc-levanilla.booth.pm/
- 相对上游的改动（阴影走原生 ShadowColor、Int 属性写入修正、拖放区、VRChat 反射化、中文化）
  由本 fork 维护，同样以 MIT 发布。详见 `LICENSE.md`。
