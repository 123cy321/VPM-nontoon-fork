# SelfLight —— 角色「自己的光源 + 自阴影」

给 avatar 一路**只照自己**的光，并让它给自己投影。

## 为什么不挂真实的 Unity Light（有官方出处）

| 事实 | 出处 |
| --- | --- |
| VRChat 性能等级里 **Lights 在 PC 上 Excellent / Good / Medium 都要求 0**，只有 Poor 允许 1 —— 挂一盏实时光直接掉档 | [Performance Ranks](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/) |
| 真实光会**照亮周围世界与其他玩家**，做不到"只照自己"。VRChat 的层是固定的：`Player(9)` 是"除本地玩家以外的玩家"，`PlayerLocal(10)` 才是本地玩家 | [Unity Layers in VRChat](https://creators.vrchat.com/worlds/layers/) |
| Unity 的 light culling mask 对自定义层本来就不可靠，而且 Quest 端实时光基本不可用 | Unity 社区结论 |

所以本功能**不产生任何 Light**：全部在着色器里完成 ⇒ 不进 VRChat 的 Lights 计数、不外溢、Quest 也能用。

## 它是怎么工作的

1. **私有光**（`Shaders/Modules/SelfLight/phase_customlight.hlsl`）：
   在 `customlight` 阶段往 `lightSum` 里加一路由材质参数定义的光（方向 / 颜色 / 强度）。
   - `Only This Light` 打开时，**丢掉世界光与环境光**并把 Shade ramp 的方向也换成它 ——
     avatar 在任何世界里长得都一样。
   - 运行时开销：1 次 `dot(N, L)`。
2. **自阴影**：一张**光照空间的正交深度图**。像素里 `worldPos` 投到光源空间后与贴图比较，
   多 1 次贴图采样 + 几个点乘。
   - 烘焙由 **`NTSelfLight` 组件**在编辑器里完成（纯 CPU 光线投射，**不需要相机 / RenderTexture / GPU**）。
3. **写入材质**：所有参数（含阴影贴图的基与范围）都写进材质属性。
   组件**运行时没有任何行为** ⇒ 烘焙完可以把它删掉，运行时零额外负担。

## 怎么用

1. 在 avatar 根节点上 **Add Component → NonToon → Self Light**。
2. `Light Source` 指定你要的那盏光源（**只读它的方向/颜色**，不会真的把它挂上去）。
3. 需要的话打开 `Only This Light`（只由它照亮）。
4. 点 **「烘焙自阴影并写入材质」**。会：
   - 采集该层级下所有 `MeshRenderer` / `SkinnedMeshRenderer`（蒙皮的按**当前姿态** `BakeMesh`）；
   - 用 `HideAndDontSave` 的临时 `MeshCollider` 逐像素朝光源方向投射射线，记录最近命中距离；
   - 写出 `Assets/NonToonSelfLight/SelfShadow_*.png`（关闭 sRGB / 压缩 / mipmap，否则深度会被改坏）；
   - 把方向、基、范围、强度、偏移写进该层级里所有带 `_UseSelfLight` 的材质。
5. 想只更新参数（不重新烘焙）就点 **「只同步光源参数」**。

## ⚠️ 注意事项

1. **渲染跟随姿态** —— 阴影是**烘焙那一刻的姿态**。换了姿势、改了网格、改了光源方向，都要**重新烘焙**。
   （VRChat 里 avatar 的姿势千变万化，所以自阴影适合"变化不大"的部位：头发的投影、脸部的立体感等。）
2. **只写进材质** —— 材质是共享资源；如果同一材质被多个 avatar/对象引用，它们会共享同一份烘焙结果。
   需要各自独立就复制一份材质。
3. **本组件运行时无行为**，烘焙后删除即可；删了也能正常显示（数据在材质里）。
4. **分辨率与耗时**：256³（默认）足够，512 更细腻但射线数 ×4；烘焙是 CPU 的，几十万条射线量级，
   大 avatar 请耐心等几秒。
5. **阴影痤疮**（表面出现条纹噪点）→ 调大 `Shadow Bias`；**漏光**（本该有阴影处发亮）→ 调大分辨率或检查光源方向。
6. **贴图必须保持** 关闭 sRGB / 不压缩 / 无 mipmap —— 这是深度数据，不是颜色。烘焙器已自动设置，
   但不要手动改 Importer。
7. **需要 NonToon (Fork) ≥ 0.2.0**（`SelfLight` 模块是 0.2.0 新增的）。
8. **和世界光的关系**：不开 `Only This Light` 时，世界光/环境光**照旧**影响 avatar，这一路光只是**额外加上去**的；
   想要"完全由它决定"就打开那个开关（代价：avatar 不再随世界变化，夜里也依然亮）。
9. **它不是阴影投射器** —— 别的物体（世界、其他玩家）**不会**被这盏光投影。这是"只照自己"的另一面。
10. **性能**：运行时不增加光照计算量，只是每像素多 1 次贴图采样 + 1 个 dot（`Only This Light` 打开时反而更省：
    世界光被丢弃了）。
