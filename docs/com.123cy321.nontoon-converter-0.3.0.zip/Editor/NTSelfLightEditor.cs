using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NonToonTools
{
    // [NT-TOOL] NTSelfLight 的检视面板：把「指定的光源」写进材质 + 烘焙自阴影。
    //
    // 注意 Int 属性必须用 SetInteger：NonToon 的 SC_uint / ShaderLab Int 属性用 SetFloat 写是**静默无效**的
    // （这个坑在材质转换器那边踩过一次：_ShadowColorEnable 写进去变 0）。
    [CustomEditor(typeof(NTSelfLight))]
    public sealed class NTSelfLightEditor : Editor
    {
        private string lastSummary;

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            var settings = (NTSelfLight)target;
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("操作", EditorStyles.boldLabel);

            if (settings.lightSource == null)
                EditorGUILayout.HelpBox("请先指定一盏光源（Light Source）。烘焙时只读取它的方向/颜色，不会真的把它挂到 avatar 上。", MessageType.Warning);

            var materials = CollectTargetMaterials(settings);
            EditorGUILayout.LabelField("层级里的 NonToon 材质", materials.Count.ToString());

            using (new EditorGUI.DisabledScope(settings.lightSource == null || materials.Count == 0))
            {
                if (GUILayout.Button("只同步光源参数（不烘焙）", GUILayout.Height(22)))
                    Apply(settings, materials, null);
                if (GUILayout.Button("烘焙自阴影并写入材质", GUILayout.Height(26)))
                {
                    var result = NTSelfShadowBaker.Bake(settings.lightSource, settings.GetComponentsInChildren<Renderer>(true), settings.shadowResolution, "Assets/NonToonSelfLight");
                    settings.bakedShadowMap = result.map;
                    EditorUtility.SetDirty(settings);
                    Apply(settings, materials, result);
                    lastSummary = "烘焙完成：" + result.map.name + "（" + result.texels + " 像素，命中 " + result.hits + "，" + result.meshCount + " 个网格）\n阴影贴图：" + result.path;
                }
            }

            if (!string.IsNullOrEmpty(lastSummary))
                EditorGUILayout.HelpBox(lastSummary, MessageType.Info);

            EditorGUILayout.HelpBox(
                "说明：本组件运行时没有任何行为 —— 所有数据都写进材质属性，烘焙完可以把它删掉。\n" +
                "之所以不用真实光源：VRChat 性能等级 PC 上要求 Lights = 0（只有 Poor 允许 1），" +
                "而且真实光会照亮周围世界与别的玩家，做不到「只照自己」。\n" +
                "改了姿态/网格/光源方向后需要重新烘焙。",
                MessageType.None);
        }

        private static List<Material> CollectTargetMaterials(NTSelfLight settings)
        {
            var result = new HashSet<Material>();
            foreach (var renderer in settings.GetComponentsInChildren<Renderer>(true))
                foreach (var material in renderer.sharedMaterials)
                    if (material != null && material.HasProperty("_UseSelfLight")) result.Add(material);
            return result.ToList();
        }

        private static void Apply(NTSelfLight settings, List<Material> materials, NTSelfShadowBaker.Result baked)
        {
            var light = settings.lightSource;
            foreach (var material in materials)
            {
                SetNumber(material, "_UseSelfLight", 1f);
                SetNumber(material, "_SelfLightOnly", settings.onlyThisLight ? 1f : 0f);
                material.SetColor("_SelfLightColor", settings.color);
                SetNumber(material, "_SelfLightIntensity", settings.intensity);
                material.SetVector("_SelfLightDirection", settings.Direction);
                SetNumber(material, "_SelfLightShadowStrength", settings.shadowStrength);
                SetNumber(material, "_SelfLightShadowBias", settings.shadowBias);

                if (baked != null && baked.map != null)
                {
                    material.SetTexture("_SelfLightShadowMap", baked.map);
                    material.SetVector("_SelfLightOrigin", baked.origin);
                    material.SetVector("_SelfLightRight", baked.right);
                    material.SetVector("_SelfLightUp", baked.up);
                    material.SetVector("_SelfLightForward", baked.forward);
                    SetNumber(material, "_SelfLightHalfX", baked.halfX);
                    SetNumber(material, "_SelfLightHalfY", baked.halfY);
                    SetNumber(material, "_SelfLightNear", baked.near);
                    SetNumber(material, "_SelfLightFar", baked.far);
                }
                else if (settings.bakedShadowMap != null)
                {
                    material.SetTexture("_SelfLightShadowMap", settings.bakedShadowMap);
                }

                EditorUtility.SetDirty(material);
            }
            AssetDatabase.SaveAssets();
            Debug.Log("[NTSelfLight] 已写入 " + materials.Count + " 个材质"
                + (light != null ? "（光源 " + light.name + "，方向 " + settings.Direction.ToString("F3") + "）" : "")
                + (baked != null ? "，并烘焙了自阴影贴图 " + (baked.map != null ? baked.map.name : "<失败>") : ""));
        }

        // Int 属性走 SetInteger，其余走 SetFloat
        private static void SetNumber(Material material, string property, float value)
        {
            if (string.IsNullOrEmpty(property) || !material.HasProperty(property)) return;
            var index = material.shader.FindPropertyIndex(property);
            if (index >= 0 && material.shader.GetPropertyType(index) == UnityEngine.Rendering.ShaderPropertyType.Int)
                material.SetInteger(property, Mathf.RoundToInt(value));
            else material.SetFloat(property, value);
        }
    }
}
