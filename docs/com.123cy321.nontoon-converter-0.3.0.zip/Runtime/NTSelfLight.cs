using UnityEngine;

namespace NonToonTools
{
    // [NT-TOOL] 「自有光源」配置组件。挂在 avatar（或任意根节点）上。
    //
    // 重要：运行时**没有任何行为**。它只是用来保存「指定哪一盏光源」+ 烘焙参数；
    // 真正的数据全部写进材质属性，烘焙完可以把它删掉。
    // 之所以不做成真的挂一盏 Unity Light：VRChat 性能等级 PC 上要求 Lights = 0
    // （只有 Poor 允许 1），而且真实光会照亮周围世界与别的玩家，做不到"只照自己"。
    [AddComponentMenu("NonToon/Self Light")]
    public sealed class NTSelfLight : MonoBehaviour
    {
        [Tooltip("指定的光源：烘焙时把它的方向/颜色/强度写进材质。不会真的产生一盏实时光。")]
        public Light lightSource;

        [Tooltip("只由这一路光照亮：忽略世界光与环境光，avatar 在任何世界里长得都一样")]
        public bool onlyThisLight;

        [Tooltip("光源颜色（可覆盖 lightSource 的颜色）")]
        public Color color = Color.white;

        [Range(0f, 4f)]
        [Tooltip("光源强度")]
        public float intensity = 1f;

        [Range(64, 1024)]
        [Tooltip("自阴影贴图分辨率。256 通常够用，512 更细腻但烘焙更慢")]
        public int shadowResolution = 256;

        [Range(0f, 1f)]
        [Tooltip("阴影强度。0 = 关闭自阴影（只用私有光）")]
        public float shadowStrength = 1f;

        [Range(0f, 0.2f)]
        [Tooltip("阴影偏移：出现自阴影痤疮（条纹状噪点）时调大")]
        public float shadowBias = 0.02f;

        [HideInInspector]
        public Texture2D bakedShadowMap;

        // 世界空间、指向光源的方向（与 Shader 里的 _SelfLightDirection 同义）
        public Vector3 Direction
        {
            get { return lightSource != null ? -lightSource.transform.forward : Vector3.up; }
        }
    }
}
