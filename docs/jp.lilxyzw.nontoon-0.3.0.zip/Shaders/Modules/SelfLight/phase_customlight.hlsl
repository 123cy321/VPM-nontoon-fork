// [NT-FEAT 7 / NT-FEAT 10] SelfLight —— 角色"自己的光源" + 类 PCSS 软自阴影。
//
// 为什么不做成真实 Unity Light（调研结论，官方出处）：
//   · VRChat 性能等级：PC 上 Excellent / Good / Medium 都要求 Lights = 0，只有 Poor 才允许 1。
//     也就是说给 avatar 挂一盏实时光，性能等级直接掉档。
//   · 真实光会**照亮周围世界与别的玩家**，做不到"只照自己"。
//     （VRChat 的层是固定的：Player(9) 是"其他玩家"，PlayerLocal(10) 才是本地玩家；
//      而且 Unity 的 light culling mask 对自定义层本来就不可靠。）
//   · Quest 端实时光基本不可用。
//
// 所以这里用**着色器侧**的办法：
//   1) 在 customlight 阶段往 lightSum 里加一路"自己的光"（方向/颜色/强度都是材质参数）；
//   2) 自阴影用**烘焙好的光照空间深度图**（由 NTSelfLight 组件烘焙；纯 CPU 光栅化，不需要相机/RT）；
//   3) 天然只影响这个材质 ⇒ 不外溢、不占 VRChat 的 Lights 计数、Quest 也能用。
//
// NT-FEAT 10 参考 nHaruka 的 PCSS4VRC「真实影システム」的思路做了三件事，
// 但手段换成"不需要实时光"的版本：
//   · PCSS 软阴影：先做 blocker search 求平均遮挡深度，再按半影大小做变半径 PCF。
//     与 PCSS4VRC 一样按距离决定柔度，但采样点是**固定 8 + 12 个**（对方也建议
//     Test Samplers ≤ 12 / Filter Samplers ≤ 24）：固定循环，无动态分支，Quest 友好。
//   · Shadow Distance：离相机超过设定距离自动关闭自阴影（PCSS4VRC 默认 10m 同理）。
//   · ReceiveMask：逐像素控制"哪里接收阴影"（对应 PCSS4VRC 的 ReceiveMask）。
//   额外给了 Shadow Density（浓度）与 Shadow Clamp（把软边压成硬边，动画风用）。
//
// 运行时开销：
//   · _SelfLightPCSS = 0 → 1 次采样（硬阴影）
//   · _SelfLightPCSS = 1 → 8 次 blocker + 12 次 PCF = 20 次采样，只在包围盒内/距离内发生
//   没有阴影图时（贴图留白）退化成纯"私有光"。
if (_UseSelfLight)
{
    half3 selfL = _SelfLightDirection.xyz;
    selfL = dot(selfL, selfL) > 0 ? normalize(selfL) : half3(0, 1, 0);

    // ---- 自阴影查询（光照空间正交投影 + 深度比较）----
    half selfShadow = 1;
    float3 selfRel = vertex.position - _SelfLightOrigin.xyz;
    float2 selfUV = float2(dot(selfRel, _SelfLightRight.xyz), dot(selfRel, _SelfLightUp.xyz));
    selfUV = selfUV / float2(max(1e-5, _SelfLightHalfX), max(1e-5, _SelfLightHalfY)) * 0.5 + 0.5;
    float selfDepth = (dot(selfRel, _SelfLightForward.xyz) - _SelfLightNear) / max(1e-5, _SelfLightFar - _SelfLightNear);

    bool ntSelfInBox = selfUV.x > 0 && selfUV.x < 1 && selfUV.y > 0 && selfUV.y < 1 && selfDepth > 0 && selfDepth < 1;
    // Shadow Distance：超过该距离直接当作无阴影（省算力，也避免远处噪点）。0 = 不裁剪。
    bool ntSelfInRange = _SelfLightDistance <= 0.0001 || distance(_WorldSpaceCameraPos, vertex.position) <= _SelfLightDistance;

    if (ntSelfInBox && ntSelfInRange)
    {
        float2 ntSelfTexel = (1.0 / max(_SelfLightShadowTexels, 8.0)).xx;
        // 逐像素旋转采样盘，避免固定图案产生的条带
        float ntSelfRot = frac(sin(dot(selfUV, float2(12.9898, 78.233))) * 43758.5453) * 6.2831853;
        float ntSelfSin = sin(ntSelfRot);
        float ntSelfCos = cos(ntSelfRot);

        if (_SelfLightPCSS > 0.5)
        {
            // ---- ① Blocker search：固定 8 点，找平均遮挡深度 ----
            float ntSelfBlockerSum = 0;
            float ntSelfBlockerCount = 0;
            [unroll]
            for (int ntSelfBI = 0; ntSelfBI < 8; ntSelfBI++)
            {
                float ntSelfBF = (ntSelfBI + 0.5) / 8.0;
                float ntSelfBA = ntSelfBI * 2.39996323 + ntSelfRot;
                float2 ntSelfBO = float2(cos(ntSelfBA), sin(ntSelfBA)) * sqrt(ntSelfBF) * ntSelfTexel * 8.0;
                float ntSelfBZ = SCSample(_SelfLightShadowMap, sampler_BaseTexture, selfUV + ntSelfBO).r;
                if (ntSelfBZ < selfDepth - _SelfLightShadowBias)
                {
                    ntSelfBlockerSum += ntSelfBZ;
                    ntSelfBlockerCount += 1;
                }
            }

            if (ntSelfBlockerCount < 0.5)
            {
                selfShadow = 1;
            }
            else
            {
                float ntSelfAvgBlocker = ntSelfBlockerSum / ntSelfBlockerCount;
                // ---- ② 半影估计（PCSS 的核心）：遮挡越远，半影越大 ----
                float ntSelfPenumbra = (selfDepth - ntSelfAvgBlocker) / max(ntSelfAvgBlocker, 1e-4) * _SelfLightSoftness;
                float ntSelfRadius = clamp(ntSelfPenumbra * 0.5, 1.5, 24.0);

                // ---- ③ 变半径 PCF：固定 12 点黄金角螺旋 ----
                float ntSelfSum = 0;
                [unroll]
                for (int ntSelfPI = 0; ntSelfPI < 12; ntSelfPI++)
                {
                    float ntSelfPF = (ntSelfPI + 0.5) / 12.0;
                    float ntSelfPA = ntSelfPI * 2.39996323 + ntSelfRot;
                    float2 ntSelfLocal = float2(cos(ntSelfPA), sin(ntSelfPA)) * sqrt(ntSelfPF) * ntSelfRadius;
                    float2 ntSelfPO = float2(
                        ntSelfLocal.x * ntSelfCos - ntSelfLocal.y * ntSelfSin,
                        ntSelfLocal.x * ntSelfSin + ntSelfLocal.y * ntSelfCos) * ntSelfTexel;
                    float ntSelfPZ = SCSample(_SelfLightShadowMap, sampler_BaseTexture, selfUV + ntSelfPO).r;
                    ntSelfSum += (selfDepth - _SelfLightShadowBias) > ntSelfPZ ? 0.0 : 1.0;
                }
                selfShadow = ntSelfSum / 12.0;
            }
        }
        else
        {
            // 硬阴影：最省的一档
            half selfOccluder = SCSample(_SelfLightShadowMap, sampler_BaseTexture, selfUV).r;
            selfShadow = (selfDepth - _SelfLightShadowBias) > selfOccluder ? 0 : 1;
        }

        if (_SelfLightShadowStrength < 0.999) selfShadow = lerp(1, selfShadow, _SelfLightShadowStrength);
        // 浓度：把阴影往"全是亮的"拉回去
        if (_SelfLightDensity < 0.999) selfShadow = lerp(1, selfShadow, _SelfLightDensity);
        // Shadow Clamp：把软过渡压成硬边（动画风），0 = 保持 PCSS 的软边
        if (_SelfLightClamp > 0.001)
        {
            float ntSelfContrast = lerp(1.0, 40.0, _SelfLightClamp);
            selfShadow = saturate((selfShadow - 0.5) * ntSelfContrast + 0.5);
        }
    }

    // ReceiveMask：0 = 完全不接收阴影，1 = 正常接收（对应 PCSS4VRC 的 ReceiveMask）
    if (_SelfLightReceiveMaskStrength > 0.001)
    {
        half ntSelfMask = NTMaskValue(SCSample(_SelfLightReceiveMask, sampler_BaseTexture, sd.uv), _SelfLightReceiveMaskChannel);
        selfShadow = lerp(1.0, selfShadow, lerp(1.0, ntSelfMask, _SelfLightReceiveMaskStrength));
    }

    half selfNdotL = saturate(dot(sd.N, selfL));
    half3 selfTerm = _SelfLightColor.rgb * (_SelfLightIntensity * selfNdotL * selfShadow);

    if (_SelfLightOnly > 0.5)
    {
        // 只由这一路光照亮：丢掉世界光与环境光，并把给 Shade ramp 用的方向也换成它，
        // 这样渐变与光照方向一致（avatar 在任何世界里长得都一样）。
        lightSum.color = selfTerm;
        lightSum.direction = selfL;
        env = 0;
    }
    else
    {
        lightSum.color += selfTerm;
    }
}
