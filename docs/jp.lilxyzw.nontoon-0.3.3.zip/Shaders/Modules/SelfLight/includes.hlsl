#ifndef NT_SELFLIGHT_SHADOW_INCLUDED
#define NT_SELFLIGHT_SHADOW_INCLUDED

// [NT-FEAT 15] 自阴影系数 —— 两条通路共用同一段计算，避免把 60 行 PCSS 抄两遍。
//
// 为什么用宏而不是函数：phase_*.hlsl 的内容会被 ShaderCore **原样拼进 frag() 内部**，
// 函数里不能再定义函数。而这个 includes.hlsl 会被拼到 include 区，宏在展开处（frag 内部）
// 才解析 SCSample / NTMaskValue / 材质属性，所以放在这里定义、在那两处展开都成立。
//
// 用法：NTSELFSHADOW(outShadow, positionWS, uv)
#ifndef NTSELFSHADOW
#define NTSELFSHADOW(outShadow, positionWS, uv) \
{ \
    outShadow = 1; \
    float3 ntSD_Rel = (positionWS) - _SelfLightOrigin.xyz; \
    float2 ntSD_UV = float2(dot(ntSD_Rel, _SelfLightRight.xyz), dot(ntSD_Rel, _SelfLightUp.xyz)); \
    ntSD_UV = ntSD_UV / float2(max(1e-5, _SelfLightHalfX), max(1e-5, _SelfLightHalfY)) * 0.5 + 0.5; \
    float ntSD_Depth = (dot(ntSD_Rel, _SelfLightForward.xyz) - _SelfLightNear) / max(1e-5, _SelfLightFar - _SelfLightNear); \
    bool ntSD_InBox = ntSD_UV.x > 0 && ntSD_UV.x < 1 && ntSD_UV.y > 0 && ntSD_UV.y < 1 && ntSD_Depth > 0 && ntSD_Depth < 1; \
    bool ntSD_InRange = _SelfLightDistance <= 0.0001 || distance(_WorldSpaceCameraPos, positionWS) <= _SelfLightDistance; \
    if (ntSD_InBox && ntSD_InRange) \
    { \
        float2 ntSD_Texel = (1.0 / max(_SelfLightShadowTexels, 8.0)).xx; \
        float ntSD_Rot = frac(sin(dot(ntSD_UV, float2(12.9898, 78.233))) * 43758.5453) * 6.2831853; \
        float ntSD_RotSin = sin(ntSD_Rot); \
        float ntSD_RotCos = cos(ntSD_Rot); \
        if (_SelfLightPCSS > 0.5) \
        { \
            int ntSD_BlockerTaps = _SelfLightPCSSQuality < 0.5 ? 8 : (_SelfLightPCSSQuality < 1.5 ? 12 : (_SelfLightPCSSQuality < 2.5 ? 20 : 32)); \
            int ntSD_FilterTaps = _SelfLightPCSSQuality < 0.5 ? 12 : (_SelfLightPCSSQuality < 1.5 ? 24 : (_SelfLightPCSSQuality < 2.5 ? 40 : 64)); \
            float ntSD_MaxRadius = ntSD_FilterTaps >= 40 ? 48.0 : 24.0; \
            float ntSD_BlockerSum = 0; \
            float ntSD_BlockerCount = 0; \
            for (int ntSD_BI = 0; ntSD_BI < ntSD_BlockerTaps; ntSD_BI++) \
            { \
                float ntSD_BF = (ntSD_BI + 0.5) / (float)ntSD_BlockerTaps; \
                float ntSD_BA = ntSD_BI * 2.39996323 + ntSD_Rot; \
                float2 ntSD_BO = float2(cos(ntSD_BA), sin(ntSD_BA)) * sqrt(ntSD_BF) * ntSD_Texel * 8.0; \
                float ntSD_BZ = _SelfLightShadowMap.SampleLevel(sampler_BaseTexture, ntSD_UV + ntSD_BO, 0).r; \
                if (ntSD_BZ < ntSD_Depth - _SelfLightShadowBias) { ntSD_BlockerSum += ntSD_BZ; ntSD_BlockerCount += 1; } \
            } \
            if (ntSD_BlockerCount < 0.5) \
            { \
                outShadow = 1; \
            } \
            else \
            { \
                float ntSD_AvgBlocker = ntSD_BlockerSum / ntSD_BlockerCount; \
                float ntSD_Penumbra = (ntSD_Depth - ntSD_AvgBlocker) / max(ntSD_AvgBlocker, 1e-4) * _SelfLightSoftness; \
                float ntSD_Radius = clamp(ntSD_Penumbra * 0.5, 1.5, ntSD_MaxRadius); \
                float ntSD_Sum = 0; \
                for (int ntSD_PI = 0; ntSD_PI < ntSD_FilterTaps; ntSD_PI++) \
                { \
                    float ntSD_PF = (ntSD_PI + 0.5) / (float)ntSD_FilterTaps; \
                    float ntSD_PA = ntSD_PI * 2.39996323 + ntSD_Rot; \
                    float2 ntSD_Local = float2(cos(ntSD_PA), sin(ntSD_PA)) * sqrt(ntSD_PF) * ntSD_Radius; \
                    float2 ntSD_PO = float2(ntSD_Local.x * ntSD_RotCos - ntSD_Local.y * ntSD_RotSin, ntSD_Local.x * ntSD_RotSin + ntSD_Local.y * ntSD_RotCos) * ntSD_Texel; \
                    float ntSD_PZ = _SelfLightShadowMap.SampleLevel(sampler_BaseTexture, ntSD_UV + ntSD_PO, 0).r; \
                    ntSD_Sum += (ntSD_Depth - _SelfLightShadowBias) > ntSD_PZ ? 0.0 : 1.0; \
                } \
                outShadow = ntSD_Sum / (float)ntSD_FilterTaps; \
            } \
        } \
        else \
        { \
            half ntSD_Occluder = _SelfLightShadowMap.SampleLevel(sampler_BaseTexture, ntSD_UV, 0).r; \
            outShadow = (ntSD_Depth - _SelfLightShadowBias) > ntSD_Occluder ? 0 : 1; \
        } \
        if (_SelfLightShadowStrength < 0.999) outShadow = lerp(1, outShadow, _SelfLightShadowStrength); \
        if (_SelfLightDensity < 0.999) outShadow = lerp(1, outShadow, _SelfLightDensity); \
        if (_SelfLightClamp > 0.001) \
        { \
            float ntSD_Contrast = lerp(1.0, 40.0, _SelfLightClamp); \
            outShadow = saturate((outShadow - 0.5) * ntSD_Contrast + 0.5); \
        } \
    } \
    if (_SelfLightReceiveMaskStrength > 0.001) \
    { \
        half ntSD_Mask = NTMaskValue(SCSample(_SelfLightReceiveMask, sampler_BaseTexture, uv), _SelfLightReceiveMaskChannel); \
        outShadow = lerp(1.0, outShadow, lerp(1.0, ntSD_Mask, _SelfLightReceiveMaskStrength)); \
    } \
}
#endif

#endif
