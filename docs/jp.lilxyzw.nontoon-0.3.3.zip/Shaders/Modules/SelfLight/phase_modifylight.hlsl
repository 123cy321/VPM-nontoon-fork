// [NT-FEAT 15] 「只由自有光源照亮」的排他通路 —— 解决"地图环境光不靠谱 / 甚至是坏的"这个场景。
//
// 为什么必须放在 modifylight 而不是 customlight：
//   birp.hlsl / urp.hlsl 的实际顺序是
//       SCCalculateAllLights:
//           env += lightmap;  env += vertexLighting;
//           __SC_PHASE_customlight__            ← 我们原来在这里写 env = 0
//           SCCalculateEnvironmentLight(...)     ← 这里又执行 env += envF + ...; env *= 1.2;
//   SH 环境光是在 customlight **之后**才累加进 env 的，所以在那儿清零等于白清：
//   地图的环境光/光照贴图/顶点光依然会漏到 avatar 上，而且 sd.L（渐变方向）也被 SH 污染。
//
//   __SC_PHASE_modifylight__ 位于 frag 里 `sd.lightColor = env + lightSum.color` 之后、
//   shade / reflection / add / postpixel 之前 —— 到这里才真正"一锤定音"。
//
// 效果：打开「只由它照亮」后，这个 avatar 的**受光与阴影完全由自己决定**，
// 在没灯、没环境光、或者环境光乱来的地图里长得都一样。
if (_UseSelfLight && _SelfLightOnly > 0.5)
{
    half3 ntSelfOnlyL = _SelfLightDirection.xyz;
    ntSelfOnlyL = dot(ntSelfOnlyL, ntSelfOnlyL) > 0 ? normalize(ntSelfOnlyL) : half3(0, 1, 0);

    half ntSelfOnlyShadow = 1;
    NTSELFSHADOW(ntSelfOnlyShadow, vertex.position, sd.uv)

    // 只保留我们这一路光：env（环境光/光照贴图/顶点光）与世界主光全部丢掉
    half3 ntSelfOnlyTerm = _SelfLightColor.rgb * (_SelfLightIntensity * saturate(dot(sd.N, ntSelfOnlyL)) * ntSelfOnlyShadow);

    // 与主通路一致的后处理链（clamp → 单色 → 无光照），保证切换开关时观感一致
    half3 ntSelfOnlyColor = clamp(ntSelfOnlyTerm, _LightMinLimit, _LightMaxLimit);
    half ntSelfOnlyGray = dot(ntSelfOnlyColor, half3(0.333333, 0.333333, 0.333333));
    ntSelfOnlyColor = lerp(ntSelfOnlyColor, half3(ntSelfOnlyGray, ntSelfOnlyGray, ntSelfOnlyGray), _MonochromeLighting);
    ntSelfOnlyColor = lerp(ntSelfOnlyColor, 1.0, _AsUnlit);
    sd.lightColor = ntSelfOnlyColor;

    // 渐变（Shade / ShadowColor 用 sd.L）的方向也换成我们自己的，
    // 否则 SCCalculateEnvironmentLight 里那句 `sd.L = lightSum.direction + SH*0.333` 会把
    // 地图环境光的颜色方向混进来，ramp 就会随地图变。
    sd.L = normalize(ntSelfOnlyL + vertex.Head * _ShadeDirectionBias + float3(0, 1, 0));

    // 后面的 reflection 相位（高光 / 环境反射）会读 env，这里一并清掉，
    // 否则"只由它照亮"的 avatar 还是会反射地图的天空盒。
    env = 0;
}
