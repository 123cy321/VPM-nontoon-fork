// [NT-FEAT 7 / NT-FEAT 10 / NT-FEAT 15] SelfLight —— 角色"自己的光源"（叠加通路）。
//
// 本文件只处理 **_SelfLightOnly = 0**：世界光照旧生效，我们这一路额外加上去。
//
// 「只由自有光源照亮」（_SelfLightOnly = 1）的排他通路在 phase_modifylight.hlsl，
// 原因：本文件跑在 SCCalculateAllLights 里、SCCalculateEnvironmentLight **之前**，
// 在那儿写 env = 0 会被后面的 `env += envF + ...; env *= 1.2;` 重新加回来
// —— 这正是 0.3.2 及以前的一个真 bug：地图的环境光其实没被关掉。
//
// 为什么不做成真实 Unity Light（调研结论，官方出处）：
//   · VRChat 性能等级：PC 上 Excellent / Good / Medium 都要求 Lights = 0，只有 Poor 才允许 1。
//   · 真实光会**照亮周围世界与别的玩家**，做不到"只照自己"。
//   · Quest 端实时光基本不可用。
//   （不在意性能等级的话，工具包里有独立的 Avatar 光源插件，本组件也有「实时光源」模式。）
//
// 自阴影计算放在 includes.hlsl 的 NTSELFSHADOW 宏里，与排他通路共用同一段代码。
if (_UseSelfLight && _SelfLightOnly < 0.5)
{
    half3 selfL = _SelfLightDirection.xyz;
    selfL = dot(selfL, selfL) > 0 ? normalize(selfL) : half3(0, 1, 0);

    half selfShadow = 1;
    NTSELFSHADOW(selfShadow, vertex.position, sd.uv)

    half selfNdotL = saturate(dot(sd.N, selfL));
    half3 selfTerm = _SelfLightColor.rgb * (_SelfLightIntensity * selfNdotL * selfShadow);
    lightSum.color += selfTerm;
}
