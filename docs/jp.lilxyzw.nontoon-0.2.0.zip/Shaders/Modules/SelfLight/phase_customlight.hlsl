// [NT-FEAT 7] SelfLight —— 角色"自己的光源"。
//
// 为什么不做成真实 Unity Light（调研结论，官方出处）：
//   · VRChat 性能等级：PC 上 Excellent / Good / Medium 都要求 Lights = 0，只有 Poor 才允许 1。
//     也就是说给 avatar 挂一盏实时光，性能等级直接掉档。
//   · 真实光会**照亮周围世界与别的玩家**，做不到"只照自己"。
//     （VRChat 的层是固定的：Player(9) 是"其他玩家"，PlayerLocal(10) 才是本地玩家；
//      而且 Unity 的 light culling mask 对自定义层本来就不可靠。）
//   · Quest 端实时光基本不可用。
//
// 所以这里用**着色器侧**的办法：
//   1) 在 customlight 阶段往 lightSum 里加一路"自己的光"（方向/颜色/强度都是材质参数）；
//   2) 自阴影用**烘焙好的光照空间深度图**（由 NTSelfLight 组件烘焙；纯 CPU 光栅化，不需要相机/RT），
//      像素里只多一次贴图采样 + 几个点乘；
//   3) 天然只影响这个材质 ⇒ 不外溢、不占 VRChat 的 Lights 计数、Quest 也能用。
//
// 运行时开销：约 1 次贴图采样 + 1 次 dot(N,L)。没有阴影图时（贴图留白）退化成纯"私有光"。
if (_UseSelfLight)
{
    half3 selfL = _SelfLightDirection.xyz;
    selfL = dot(selfL, selfL) > 0 ? normalize(selfL) : half3(0, 1, 0);

    // ---- 自阴影查询（光照空间正交投影 + 深度比较）----
    half selfShadow = 1;
    float3 selfRel = vertex.position - _SelfLightOrigin.xyz;
    float2 selfUV = float2(dot(selfRel, _SelfLightRight.xyz), dot(selfRel, _SelfLightUp.xyz));
    selfUV = selfUV / float2(max(1e-5, _SelfLightHalfX), max(1e-5, _SelfLightHalfY)) * 0.5 + 0.5;
    float selfDepth = (dot(selfRel, _SelfLightForward.xyz) - _SelfLightNear) / max(1e-5, _SelfLightFar - _SelfLightNear);
    if (selfUV.x > 0 && selfUV.x < 1 && selfUV.y > 0 && selfUV.y < 1 && selfDepth > 0 && selfDepth < 1)
    {
        half selfOccluder = SCSample(_SelfLightShadowMap, sampler_BaseTexture, selfUV).r;
        selfShadow = (selfDepth - _SelfLightShadowBias) > selfOccluder ? 0 : 1;
        selfShadow = lerp(1, selfShadow, _SelfLightShadowStrength);
    }

    half selfNdotL = saturate(dot(sd.N, selfL));
    half3 selfTerm = _SelfLightColor.rgb * (_SelfLightIntensity * selfNdotL * selfShadow);

    if (_SelfLightOnly > 0.5)
    {
        // 只由这一路光照亮：丢掉世界光与环境光，并把给 Shade ramp 用的方向也换成它，
        // 这样渐变与光照方向一致（avatar 在任何世界里长得都一样）。
        lightSum.color = selfTerm;
        lightSum.direction = selfL;
        env = 0;
    }
    else
    {
        lightSum.color += selfTerm;
    }
}
