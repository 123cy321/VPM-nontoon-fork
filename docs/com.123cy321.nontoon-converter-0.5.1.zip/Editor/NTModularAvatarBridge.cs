using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace NonToonTools
{
    // [NT-FEAT 22] Modular Avatar 桥 —— **软依赖**。
    //
    // 装了就自动走非破坏模式：只生成资产 + 往 avatar 根节点挂 MA 的组件，
    // **绝不修改**用户的 FX 控制器 / ExpressionParameters / ExpressionsMenu；
    // 没装就返回不可用，调用方回退到 NTVrcParameterBuilder 的"直接改控制器"老路径。
    //
    // 全走反射（与 VRCSDK / AAO 的做法一致）：本包不引入 MA 硬依赖、也不加 asmdef 引用。
    //
    // 挂哪四个（缺一不可，读 MA 1.18.1 源码确认）：
    //   1. ModularAvatarMergeAnimator   —— 把生成的控制器并进 FX 层（pathMode=Relative、匹配 WD）
    //   2. ModularAvatarParameters      —— 注册 Float 参数（syncType=Float；localOnly = 不同步给别人）
    //   3. ModularAvatarMenuItem        —— 径向菜单项（VRCExpressionsMenu.Control.type = RadialPuppet）
    //   4. ModularAvatarMenuInstaller   —— **必须**：MA 只在存在 installer 时才安装菜单
    //      （Editor/MenuInstallHook.cs:35 `if (menuInstallers.Length == 0) return;`）
    // 四个都挂在 **avatar 根节点**：这样 MergeAnimator 的相对路径前缀为空，
    // 与剪辑里"相对 avatar 根"的绑定路径一致；installer 也能在同一节点上找到 MenuItem。
    internal static class NTModularAvatarBridge
    {
        const string NS = "nadena.dev.modular_avatar.core.";

        internal sealed class Result
        {
            public readonly List<string> Done = new List<string>();
            public readonly List<string> Errors = new List<string>();
            public bool Ok { get { return Errors.Count == 0; } }
        }

        // ---------------------------------------------------------------- 探测
        static Type Find(string fullName)
        {
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                var t = asm.GetType(fullName, false);
                if (t != null) return t;
            }
            return null;
        }

        internal static Type MergeAnimatorType { get { return Find(NS + "ModularAvatarMergeAnimator"); } }

        internal static bool IsAvailable { get { return MergeAnimatorType != null; } }

        // MA 版本（给面板显示用；读不到就返回 null）
        internal static string Version
        {
            get
            {
                var t = MergeAnimatorType;
                if (t == null) return null;
                try
                {
                    var info = UnityEditor.PackageManager.PackageInfo.FindForAssembly(t.Assembly);
                    return info != null ? info.version : null;
                }
                catch { return null; }
            }
        }

        // ---------------------------------------------------------------- 反射小工具
        static FieldInfo F(Type t, string n)
        {
            return t?.GetField(n, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        }

        static void SetField(object o, string n, object v)
        {
            var f = F(o?.GetType(), n);
            if (f == null) throw new MissingFieldException((o?.GetType().Name ?? "null") + "." + n);
            f.SetValue(o, v);
        }

        static void SetEnumField(object o, string n, string enumName)
        {
            var f = F(o?.GetType(), n);
            if (f == null) throw new MissingFieldException((o?.GetType().Name ?? "null") + "." + n);
            var underlying = Nullable.GetUnderlyingType(f.FieldType) ?? f.FieldType;
            if (!underlying.IsEnum) throw new InvalidOperationException(n + " 不是枚举（" + underlying.Name + "）");
            f.SetValue(o, Enum.Parse(underlying, enumName, true));
        }

        static Component AddOrGet(GameObject go, Type t)
        {
            var existing = go.GetComponent(t);
            if (existing != null) return existing;
            return Undo.AddComponent(go, t);
        }

        // ---------------------------------------------------------------- 主入口
        // controller：NTVrcParameterBuilder 以 standalone 模式生成的独立控制器
        internal static Result Attach(GameObject avatarRoot, AnimatorController controller, string paramName,
                                      bool synced, float defaultValue, string menuLabel)
        {
            var r = new Result();
            if (avatarRoot == null) { r.Errors.Add("没有 avatar 根节点"); return r; }
            if (controller == null) { r.Errors.Add("没有可合并的 AnimatorController"); return r; }

            var mergeType = MergeAnimatorType;
            var paramsType = Find(NS + "ModularAvatarParameters");
            var itemType = Find(NS + "ModularAvatarMenuItem");
            var installerType = Find(NS + "ModularAvatarMenuInstaller");
            var cfgType = Find(NS + "ParameterConfig");
            var missing = new List<string>();
            if (mergeType == null) missing.Add("MergeAnimator");
            if (paramsType == null) missing.Add("Parameters");
            if (itemType == null) missing.Add("MenuItem");
            if (installerType == null) missing.Add("MenuInstaller");
            if (cfgType == null) missing.Add("ParameterConfig");
            if (missing.Count > 0) { r.Errors.Add("Modular Avatar 组件不完整，缺少：" + string.Join("、", missing)); return r; }

            try
            {
                // 1) Merge Animator
                var merge = AddOrGet(avatarRoot, mergeType);
                SetField(merge, "animator", controller);
                SetEnumField(merge, "layerType", "FX");          // VRCAvatarDescriptor.AnimLayerType.FX
                SetEnumField(merge, "pathMode", "Relative");     // MergeAnimatorPathMode.Relative
                SetField(merge, "matchAvatarWriteDefaults", true);
                EditorUtility.SetDirty(merge);
                r.Done.Add("MA Merge Animator → " + controller.name + "（FX 层、相对路径、匹配 Write Defaults）");

                // 2) Parameters
                var pars = AddOrGet(avatarRoot, paramsType);
                var listField = F(paramsType, "parameters");
                if (listField == null) throw new MissingFieldException("ModularAvatarParameters.parameters");
                var list = listField.GetValue(pars) as IList;
                if (list == null)
                {
                    list = (IList)Activator.CreateInstance(listField.FieldType);
                    listField.SetValue(pars, list);
                }
                for (var i = list.Count - 1; i >= 0; i--)       // 幂等：同名先删
                {
                    var existingName = F(cfgType, "nameOrPrefix")?.GetValue(list[i]) as string;
                    if (existingName == paramName) list.RemoveAt(i);
                }
                var cfg = Activator.CreateInstance(cfgType);
                SetField(cfg, "nameOrPrefix", paramName);
                SetEnumField(cfg, "syncType", "Float");         // ParameterSyncType.Float
                SetField(cfg, "localOnly", !synced);            // 「同步给别人看」的开关
                SetField(cfg, "saved", true);
                SetField(cfg, "defaultValue", defaultValue);
                SetField(cfg, "hasExplicitDefaultValue", true);
                list.Add(cfg);
                EditorUtility.SetDirty(pars);
                r.Done.Add("MA Parameters → Float " + paramName + "（默认 " + defaultValue.ToString("F2")
                           + (synced ? "，同步给别人" : "，仅自己可见（localOnly）") + "）");

                // 3) Menu Item（径向）
                var item = AddOrGet(avatarRoot, itemType);
                SetField(item, "label", menuLabel);
                SetField(item, "isSynced", synced);
                SetField(item, "isSaved", true);
                SetControl(item, itemType, paramName, synced);
                EditorUtility.SetDirty(item);
                r.Done.Add("MA Menu Item → 径向「" + menuLabel + "」绑定 " + paramName);

                // 4) Menu Installer（没有它 MA 根本不会装菜单）
                var installer = AddOrGet(avatarRoot, installerType);
                EditorUtility.SetDirty(installer);
                r.Done.Add("MA Menu Installer → 把上面的菜单项装进 avatar 根菜单（不需要手动摆菜单资产）");
            }
            catch (Exception e)
            {
                r.Errors.Add("挂 MA 组件失败：" + (e.InnerException ?? e).Message);
            }
            return r;
        }

        // ModularAvatarMenuItem.Control 是 `VRCExpressionsMenu.Control?`（可空结构体），
        // 所以在 VRCSDK 存在时直接构造那个结构体并塞进可空字段。
        static void SetControl(Component item, Type itemType, string paramName, bool synced)
        {
            var ctrlField = F(itemType, "Control");
            var portableField = F(itemType, "Control") == null ? F(itemType, "control") : null;
            var field = ctrlField ?? portableField;
            if (field == null) throw new MissingFieldException("ModularAvatarMenuItem.Control");

            var fieldType = field.FieldType;
            var underlying = Nullable.GetUnderlyingType(fieldType) ?? fieldType;
            var control = Activator.CreateInstance(underlying);

            // name / type / parameter / value —— 逐项尽力设置（字段名变化时不至于整体失败）
            TrySet(control, "name", "亮度");
            var typeField = F(underlying, "type");
            if (typeField != null && typeField.FieldType.IsEnum)
                typeField.SetValue(control, Enum.Parse(typeField.FieldType, "RadialPuppet", true));
            var paramField = F(underlying, "parameter");
            if (paramField != null)
            {
                var paramStructType = paramField.FieldType;
                var ps = Activator.CreateInstance(paramStructType);
                TrySet(ps, "name", paramName);
                paramField.SetValue(control, ps);
            }
            TrySet(control, "value", 1f);
            // labels / subParameters / subMenu 留空（MA 会用上面的 label 字段当显示名）
            var boxed = underlying == fieldType ? control : Activator.CreateInstance(fieldType, control);
            field.SetValue(item, boxed);
        }

        static void TrySet(object o, string name, object value)
        {
            var f = F(o?.GetType(), name);
            if (f != null) f.SetValue(o, value);
        }
    }
}
