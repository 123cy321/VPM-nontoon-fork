SC_color(_SpecularColor, (0,0,0,1), [], "__Color", "")
SC_float(_SpecularMultiplyAlbedo, 0, [SCRange(0,1)], "__MultiplyAlbedo", "")
SC_uint(_SpecularMaskChannel, 3, [SCMaskChannel], "__MaskChannel", "")
// [NT-FIX 6] Fresnel F0 was hardcoded to 0.04 (dielectric glass/plastic) in phase_light.hlsl,
// which made metal-like or wet surfaces impossible to express. Default is unchanged at 0.04,
// so existing materials render identically until this is touched. Raise toward 1.0 for metal.
SC_float(_SpecularF0, 0.04, [SCRange(0,1)], "Specular F0", "")
