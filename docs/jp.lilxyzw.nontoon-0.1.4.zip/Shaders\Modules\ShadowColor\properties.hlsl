// [NT-FEAT 2] lilToon shadow colour (1st / 2nd / 3rd) with border/blur ramps.
//
// This module's .scmodule sets "keepPropertyNames": true, which makes ShaderCore pass an empty
// uniqueID to SCProperty.FromFile, so these names are NOT prefixed. That is deliberate: the names
// and defaults are copied character-for-character from lilToon's Shader/lts.shader, so values
// migrate 1:1 and a material switched from lilToon to NonToon carries them over.
//
// Only properties this module actually reads are declared - lilToon parameters that are not
// ported (see the migration table in unity/_notes) are omitted rather than declared dead.

SC_Box
SC_uint(_ShadowColorEnable, 0, [SCToggle], "Enable", "")
SC_color(_ShadowColor, (0.82,0.76,0.85,1.0), [], "Shadow Color", "")
SC_Texture2D(_ShadowColorTex, "black", [], "Shadow Color", "")
SC_float(_ShadowBorder, 0.5, [SCRange(0,1)], "Border", "")
SC_float(_ShadowBlur, 0.1, [SCRange(0,1)], "Blur", "")
SC_BoxEnd

SC_Box
SC_color(_Shadow2ndColor, (0.68,0.66,0.79,1), [], "2nd Color", "")
SC_Texture2D(_Shadow2ndColorTex, "black", [], "2nd Color", "")
SC_float(_Shadow2ndBorder, 0.15, [SCRange(0,1)], "2nd Border", "")
SC_float(_Shadow2ndBlur, 0.1, [SCRange(0,1)], "2nd Blur", "")
SC_BoxEnd

SC_Box
// lilToon default is (0,0,0,0). The alpha is this level's coverage, so a = 0 disables the 3rd
// level by default - identical to lilToon's behaviour, and safe.
SC_color(_Shadow3rdColor, (0,0,0,0), [], "3rd Color", "")
SC_Texture2D(_Shadow3rdColorTex, "black", [], "3rd Color", "")
SC_float(_Shadow3rdBorder, 0.25, [SCRange(0,1)], "3rd Border", "")
SC_float(_Shadow3rdBlur, 0.1, [SCRange(0,1)], "3rd Blur", "")
SC_BoxEnd

SC_Box
SC_float(_ShadowStrength, 1, [SCRange(0,1)], "Strength", "")
SC_float(_ShadowBorderRange, 0.08, [SCRange(0,1)], "Border Range", "")
SC_color(_ShadowBorderColor, (1,0.1,0,1), [], "Border Color", "")
SC_float(_ShadowMainStrength, 0, [SCRange(0,1)], "Contrast", "")
// lilToon name kept for migration; feeds the fwidth() antialiasing term.
SC_float(_AAStrength, 1, [SCRange(0,4)], "AA Strength", "")
// NonToon-native masking: a channel of the shared mask texture, like _SpecularMaskChannel.
// (lilToon instead uses dedicated _ShadowStrengthMask/BorderMask/BlurMask textures - see the
// migration table in unity/_notes.)
SC_uint(_ShadowStrengthMaskChannel, 3, [SCMaskChannel], "__MaskChannel", "")
SC_BoxEnd
