// [NT-FEAT 24] 「NonToon 光影」子菜单 —— **独立控制项**，不是一个大杂烩轮盘。
//
// ── 用户 2026-09-17 的明确要求（原文）───────────────────────────────────────
//   「我需要**单独**可以调整**阴影强度**和**阴影开关**，和**光照的上限和下限**，
//     而不是一个不明不白的轮盘。应该是**创建一个子菜单**然后将开关轮盘放入」
//
// ⇒ 结构（**这就是 MA 官方文档 `menu-item#submenus` 说的做法**）：
//
//   <Avatar>
//     └── NT_Menu_NonToon            [MenuItem(type=SubMenu, MenuSource=Children) + MenuInstaller]
//           ├── NT_Menu_MinLimit         RadialPuppet  → NT_MinLimit         → 材质 _LightMinLimit
//           ├── NT_Menu_MaxLimit         RadialPuppet  → NT_MaxLimit         → 材质 _LightMaxLimit
//           ├── NT_Menu_ShadowStrength   RadialPuppet  → NT_ShadowStrength   → ⑥ 组件 shadowFloor（反向）
//           ├── NT_Menu_ShadowOn         Toggle        → NT_ShadowOn         → ⑥ 组件 pcssOn
//
//   MA 的 `ModularAvatarMenuItem.Visit()` 里：
//     `if (cloned.type == SubMenu) case SubmenuSource.Children: cloned.SubmenuNode = NodeFor(new MenuNodesUnder(本物体))`
//   ⇒ 三个必要条件：`Control.type = SubMenu`、`MenuSource = Children`、
//      子项 MenuItem 挂在本物体的**直接子级**。**子项不需要各自的 installer**
//      （挂了反会被重复装到根菜单 —— `NTModularAvatarBridge.AddMenuItemOn(addInstaller:false)`）。
//
// ── 为什么不再用"一个观感档位"──────────────────────────────────────────────
// 那套把 5 个量压成一个 0..1 的值，用一个径向选"第几档"。用户明确否掉：
// 独立量必须**各自可调**。于是每个量一条 FX 层（`Simple1D`，2 个关键剪辑）。
//
// ── 同步预算：**≤ 30 bit**（用户 2026-09-17 的硬指标：「好吧30以内包括」）──
//   VRChat 官方位宽（`animator-parameters#parameter-types`）：**`Bool` = 1 bit、`Int` = 8 bit、`Float` = 8 bit**。
//   MA 官方（`reference/parameters#savedsynced`）：*"If you clear this box, this parameter
//   won't use your limited parameter space."* ⇒ **不同步 = 0 bit**。
//
//   | 控制项 | 参数 | 类型 | 位宽 |
//   |---|---|---|---|
//   | 光照下限（防煤） | `NT_MinLimit` | `Float` | 8 |
//   | 光照上限（压过曝） | `NT_MaxLimit` | `Float` | 8 |
//   | 阴影强度 | `NT_ShadowStrength` | `Float` | 8 |
//   | 阴影开关 | `NT_ShadowOn` | **`Bool`** | **1** |
//   | **合计** | | | **25 / 30 bit** ✅ |
//
//   ⇒ 用户最初要的四项**全部满配**（三条连续滑块 + 一个开关），还剩 5 bit 余量。
//   （历史：先做过"一个观感轮盘"被否掉；改成 5 项独立时是 33 bit，用户要求 ≤20，
//     数学上 3 条连续量最少 24 bit ⇒ 当时把「光照上限」降级成开关做到 18；
//     用户随后放宽到 30 ⇒ 恢复成连续滑块，得 25。）
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace NonToonTools
{
    internal static class NTLightMenuSetup
    {
        internal const string SubmenuLabel = "NonToon 光影";
        internal const string SubmenuHost = "NT_Menu_NonToon";
        const string Folder = "Assets/NonToonLightMenu";
        const string CtrlPath = Folder + "/NTLightMenu.controller";

        internal const string P_Min = "NT_MinLimit";
        internal const string P_Max = "NT_MaxLimit";
        internal const string P_ShadowStrength = "NT_ShadowStrength";
        internal const string P_ShadowOn = "NT_ShadowOn";

        // ── 各量的实际区间（菜单参数是归一化 0..1）──
        // 光照下限：连续 0.0 .. 0.6（防煤；NonToon 默认 0 ⇒ 全黑地图会变煤）
        const float MinLo = 0f, MinHi = 0.6f, MinDefault = 0.25f;
        // 光照上限：连续 **0.2 .. 1.0**（压过曝；默认 1.0 = 不压）
        // ⚠️ 原来从 0.4 起步 —— 对**深色角色**几乎看不出效果：`clamp` 只在上限**低于实际渲染亮度**
        //    时才起作用，而深色的 RGB 本来就很少超过 0.4。实测这只 avatar 的 Body 等材质 `_Color` 是纯黑，
        //    渲染亮度普遍低于 0.4 ⇒ 0.4 起步等于白拉。改成 0.2 起步。
        const float MaxLo = 0.2f, MaxHi = 1f, MaxDefault = 1f;
        // 阴影强度：连续，**反向**（参数 1 → shadowFloor 0.0 = 影最重；参数 0 → 0.95 = 几乎无影）
        // ⚠️ 弱端原来是 0.6（影只淡 40%），实测"拉了几乎没变" ⇒ 改成 **0.95**，
        //    两端变成"几乎无影 ↔ 最重"，全程都有明显变化。
        //    0.95 正好是组件字段 `[Range(0f,0.95f)]` 的上界（动画曲线不受 Range 约束，但保持自洽更好）。
        const float FloorLo = 0f, FloorHi = 0.95f, FloorDefault = 0.25f;

        static float Norm(float v, float lo, float hi) { return Mathf.Clamp01((v - lo) / Mathf.Max(hi - lo, 1e-6f)); }

        internal sealed class Result
        {
            public readonly List<string> Done = new List<string>();
            public readonly List<string> Warnings = new List<string>();
            public readonly List<string> Errors = new List<string>();
            public bool Ok { get { return Errors.Count == 0; } }
        }

        [MenuItem("Tools/NonToon/⑥ 光影菜单（子菜单：光照上下限 / 阴影强度 / 阴影开关）", false, 56)]
        private static void RunMenu()
        {
            var root = Selection.gameObjects.FirstOrDefault(g => g != null && g.transform.parent == null);
            if (root == null)
            {
                EditorUtility.DisplayDialog("NonToon 光影菜单", "请先在 Hierarchy 里选中 avatar 根节点。", "好");
                return;
            }
            EditorUtility.DisplayDialog("NonToon 光影菜单", Report(Install(root, true)), "好");
        }

        internal static string Report(Result r)
        {
            var sb = new List<string>();
            sb.AddRange(r.Done.Select(x => "· " + x));
            sb.AddRange(r.Warnings.Select(x => "⚠️ " + x));
            sb.AddRange(r.Errors.Select(x => "❌ " + x));
            return string.Join("\n", sb.ToArray());
        }

        /// <summary>核心逻辑，**不弹任何对话框**（供脚本 / 探针 / 自动化调用）。</summary>
        internal static Result Install(GameObject avatarRoot, bool addMenu)
        {
            var r = new Result();
            if (avatarRoot == null) { r.Errors.Add("没有 avatar 根节点"); return r; }
            if (!NTModularAvatarBridge.IsAvailable)
            {
                r.Errors.Add("本工程里没装 Modular Avatar。菜单只走声明式路径（不会改你的资产）。");
                return r;
            }

            var compType = FindType("NonToon.NTSelfRealtimeShadow");
            if (compType == null) { r.Errors.Add("找不到 NonToon.NTSelfRealtimeShadow（工具包 Runtime 没装？）"); return r; }

            // ---- 确保 ⑥ 灯架存在（**不装它自己的菜单**，菜单由本类统一负责）----
            // 无条件走一遍 `NTSelfRealtimeSetup.Install`：它现在会**自愈**（去重 + 把灯架拉回 avatar 根下），
            // 所以这里不再用 `Find` 去判断"有没有"——那只找直接子级，重复体藏在子菜单里时判断不出来。
            var setupType = FindType("NonToonTools.NTSelfRealtimeSetup");
            setupType.GetMethod("Install", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public)
                     .Invoke(null, new object[] { avatarRoot, false, 5f, 64f, 1f, 8f, 110f, false });
            var rigT = avatarRoot.transform.Find(NTSelfRealtimeSetup.RigName);
            if (rigT == null) { r.Errors.Add("没能建出 ⑥ 的灯架"); return r; }
            var rig = rigT.gameObject;
            var rigRel = rig.name;

            // ---- 材质侧：光照上下限要作用的 renderer ----
            var minRds = new List<Renderer>();
            var maxRds = new List<Renderer>();
            foreach (var rd in avatarRoot.GetComponentsInChildren<Renderer>(true))
            {
                if (rd == null) continue;
                foreach (var m in rd.sharedMaterials)
                {
                    if (m == null) continue;
                    if (m.HasProperty("_LightMinLimit") && !minRds.Contains(rd)) minRds.Add(rd);
                    if (m.HasProperty("_LightMaxLimit") && !maxRds.Contains(rd)) maxRds.Add(rd);
                }
            }
            if (minRds.Count == 0) r.Warnings.Add("没有任何材质的 _LightMinLimit ⇒ 「光照下限」这条曲线会是空的。");
            if (maxRds.Count == 0) r.Warnings.Add("没有任何材质的 _LightMaxLimit ⇒ 「光照上限」这条曲线会是空的。");

            // ---- 生成控制器 ----
            EnsureFolder(Folder);
            if (AssetDatabase.LoadAssetAtPath<AnimatorController>(CtrlPath) != null) AssetDatabase.DeleteAsset(CtrlPath);
            foreach (var g in AssetDatabase.FindAssets("t:AnimationClip", new[] { Folder }))
                AssetDatabase.DeleteAsset(AssetDatabase.GUIDToAssetPath(g));

            var ctrl = AnimatorController.CreateAnimatorControllerAtPath(CtrlPath);
            AddFloatParam(ctrl, P_Min, Norm(MinDefault, MinLo, MinHi));
            AddFloatParam(ctrl, P_Max, Norm(MaxDefault, MaxLo, MaxHi));
            AddFloatParam(ctrl, P_ShadowStrength, Norm(FloorDefault, FloorLo, FloorHi));   // 反向 → 见下
            // ⚡ 开关用 **Bool**：VRChat 里 `Bool` 只占 **1 bit**（`Float`/`Int` 都是 8 bit）。
            //    动画侧也用 Bool 参数 + 两状态机（故意不玩"声明 Bool / 动画 Float"的跨类型转换）
            AddBoolParam(ctrl, P_ShadowOn, false);     // 阴影开关，**默认关**（自带阴影默认关闭）
            // 删掉 CreateAnimatorControllerAtPath 附送的空 Base Layer
            for (var i = ctrl.layers.Length - 1; i >= 0; i--)
            {
                var L = ctrl.layers[i];
                if (L.name == "Base Layer" && (L.stateMachine == null || L.stateMachine.states.Length == 0)) ctrl.RemoveLayer(i);
            }

            // 1) 光照下限：0..1 → 材质 _LightMinLimit 0.0 .. 0.6（**连续**，防煤主力）
            AddLayer(ctrl, P_Min, "MinLimit",
                (clip, v) => { foreach (var rd in minRds) AddMat(clip, avatarRoot, rd, "_LightMinLimit", v); },
                MinLo, MinHi);
            // 2) 光照上限：0..1 → 材质 _LightMaxLimit 0.4 .. 1.0（**连续**，压过曝）
            AddLayer(ctrl, P_Max, "MaxLimit",
                (clip, v) => { foreach (var rd in maxRds) AddMat(clip, avatarRoot, rd, "_LightMaxLimit", v); },
                MaxLo, MaxHi);
            // 3) 阴影强度：**连续**，反向 —— 参数 0 → shadowFloor 0.6（影最淡），参数 1 → 0.0（影最重）
            AddLayer(ctrl, P_ShadowStrength, "ShadowStrength",
                (clip, v) => AddField(clip, rigRel, compType, "shadowFloor", v),
                FloorHi, FloorLo);
            // 4) 阴影开关（**Bool**，1 bit）→ pcssOn
            AddBoolLayer(ctrl, P_ShadowOn, "ShadowOn", defaultOn: false,
                (clip, v) => AddField(clip, rigRel, compType, "pcssOn", v));

            AssetDatabase.SaveAssets();
            r.Done.Add("生成控制器 " + CtrlPath + "：4 条层（光照下限 / 光照上限 / 阴影强度 / 阴影开关）");

            if (!addMenu) return r;

            // ---- MA：控制器 + 4 个参数 + **子菜单** ----
            var c = NTModularAvatarBridge.AttachControllerOnly(avatarRoot, ctrl);
            r.Done.AddRange(c.Done); r.Errors.AddRange(c.Errors);

            AddParam(avatarRoot, P_Min, Norm(MinDefault, MinLo, MinHi), r);
            AddParam(avatarRoot, P_Max, Norm(MaxDefault, MaxLo, MaxHi), r);
            AddParam(avatarRoot, P_ShadowStrength, Norm(FloorDefault, FloorLo, FloorHi), r);
            // ⚡ 开关声明成 Bool ⇒ **1 bit**（Float 要 8 bit）。Bool 默认值用 1/0。
            AddParam(avatarRoot, P_ShadowOn, 0f, r, syncType: "Bool");   // 默认关
            r.Done.Add("同步预算：3 × Float(8 bit) + 1 × Bool(1 bit) = **25 / 256 bit**（目标 ≤30 ✅）");

            // 子菜单宿主
            var hostT = avatarRoot.transform.Find(SubmenuHost);
            GameObject host;
            if (hostT == null)
            {
                host = new GameObject(SubmenuHost);
                Undo.RegisterCreatedObjectUndo(host, "NonToon 光影子菜单");
                host.transform.SetParent(avatarRoot.transform, false);
            }
            else host = hostT.gameObject;

            var sm = NTModularAvatarBridge.AddSubmenuOn(host, avatarRoot, SubmenuLabel);
            r.Done.AddRange(sm.Done); r.Errors.AddRange(sm.Errors);

            // 子项（**不各自挂 installer** —— 靠父 MenuItem 的 Children 模式收进去）
            ChildMenuItem(host, avatarRoot, "NT_Menu_MinLimit", P_Min, "光照下限", "RadialPuppet", r);
            ChildMenuItem(host, avatarRoot, "NT_Menu_MaxLimit", P_Max, "光照上限", "RadialPuppet", r);
            ChildMenuItem(host, avatarRoot, "NT_Menu_ShadowStrength", P_ShadowStrength, "阴影强度", "RadialPuppet", r);
            ChildMenuItem(host, avatarRoot, "NT_Menu_ShadowOn", P_ShadowOn, "阴影开关", "Toggle", r);

            RemoveLegacyMenu(avatarRoot, r);
            r.Done.Add("菜单结构：根菜单 →「" + SubmenuLabel + "」子菜单 → 4 个独立控制项");
            return r;
        }

        static void ChildMenuItem(GameObject parent, GameObject avatarRoot, string goName,
                                  string param, string label, string type, Result r)
        {
            var t = parent.transform.Find(goName);
            GameObject go;
            if (t == null)
            {
                go = new GameObject(goName);
                Undo.RegisterCreatedObjectUndo(go, "NonToon 光影子项");
                go.transform.SetParent(parent.transform, false);
            }
            else go = t.gameObject;
            var res = NTModularAvatarBridge.AddMenuItemOn(go, avatarRoot, param, true, label, type, addInstaller: false);
            r.Done.AddRange(res.Done); r.Errors.AddRange(res.Errors);
        }

        static void AddParam(GameObject avatarRoot, string name, float def, Result r, string syncType = "Float")
        {
            // synced: true（别人也要看到同样的亮度/影子）+ saved: true（记住你的选择）
            // ⚠️ VRChat 规则：`Saved` 必须同时 `Synced` ⇒ 「省参数(0 bit)」与「记住设置」不可兼得。
            var p = NTModularAvatarBridge.AddParameter(avatarRoot, name, true, def, saved: true, syncType: syncType);
            r.Done.AddRange(p.Done); r.Errors.AddRange(p.Errors);
        }

        /// <summary>摘掉以前几版设计留下的菜单项 / 参数（都是我们自己的），避免重复或叠加。</summary>
        static void RemoveLegacyMenu(GameObject avatarRoot, Result r)
        {
            var legacyParams = new[] { "NT_Light", "NT_Look", NTSelfRealtimeSetup.ParamName,
                                       NTSelfRealtimeSetup.ParamFloor, NTSelfRealtimeSetup.ParamOn,
                                       NTSelfRealtimeSetup.ParamIntensity };
            var paramsType = FindType("nadena.dev.modular_avatar.core.ModularAvatarParameters");
            var cfgType = FindType("nadena.dev.modular_avatar.core.ParameterConfig");
            var pars = paramsType == null ? null : avatarRoot.GetComponent(paramsType);
            var listField = paramsType == null ? null : paramsType.GetField("parameters");
            var list = pars == null || listField == null ? null : listField.GetValue(pars) as IList;
            var nameField = cfgType == null ? null : cfgType.GetField("nameOrPrefix");
            if (list != null)
                for (var i = list.Count - 1; i >= 0; i--)
                {
                    var nm = nameField == null ? null : nameField.GetValue(list[i]) as string;
                    if (nm != null && legacyParams.Contains(nm))
                    {
                        list.RemoveAt(i);
                        r.Done.Add("摘掉旧设计的参数 " + nm);
                    }
                }
            if (pars != null) EditorUtility.SetDirty(pars);

            // 旧 host（根上的平级菜单项 / 灯架上的子物体）
            var legacyHosts = legacyParams.Select(NTModularAvatarBridge.HostName)
                                          .Concat(new[] { "NT_Menu_NT_Look" }).ToArray();
            foreach (var hn in legacyHosts)
            {
                var t = avatarRoot.transform.Find(hn);
                if (t != null) { Undo.DestroyObjectImmediate(t.gameObject); r.Done.Add("摘掉旧 host " + hn); }
            }
            var rig = avatarRoot.transform.Find(NTSelfRealtimeSetup.RigName);
            if (rig != null)
                foreach (var n in new[] { "Menu_ShadowFloor", "Menu_OnOff", "Menu_LightIntensity" })
                {
                    var t = rig.Find(n);
                    if (t != null) { Undo.DestroyObjectImmediate(t.gameObject); r.Done.Add("摘掉旧 host " + n); }
                }

            // 旧设计的 MergeAnimator（非本控制器的那些）
            var mergeType = FindType("nadena.dev.modular_avatar.core.ModularAvatarMergeAnimator");
            var keep = AssetDatabase.LoadAssetAtPath<AnimatorController>(CtrlPath);
            if (mergeType != null)
            {
                var animField = mergeType.GetField("animator");
                foreach (var mc in avatarRoot.GetComponents(mergeType).ToArray())
                {
                    if (mc == null) continue;
                    var a = animField.GetValue(mc) as UnityEngine.Object;
                    if (a != null && !ReferenceEquals(a, keep))
                    { Undo.DestroyObjectImmediate(mc); r.Done.Add("摘掉旧 MergeAnimator（" + a.name + "）"); }
                }
            }
        }

        // ------------------------------------------------------------------ 生成工具
        static void AddFloatParam(AnimatorController ctrl, string name, float def)
        {
            ctrl.AddParameter(name, AnimatorControllerParameterType.Float);
            var ps = ctrl.parameters;
            for (var i = 0; i < ps.Length; i++) if (ps[i].name == name) ps[i].defaultFloat = def;
            ctrl.parameters = ps;
        }

        static void AddBoolParam(AnimatorController ctrl, string name, bool def)
        {
            ctrl.AddParameter(name, AnimatorControllerParameterType.Bool);
            var ps = ctrl.parameters;
            for (var i = 0; i < ps.Length; i++) if (ps[i].name == name) ps[i].defaultBool = def;
            ctrl.parameters = ps;
        }

        /// <summary>一条 1D 混合层：参数 0..1 → `lo`..`hi`。
        ///   `defaultWeight` **必须是 1**（`AddLayer(string)` 那个重载会建出 0 ⇒ 整层不生效）。</summary>
        static void AddLayer(AnimatorController ctrl, string param, string tag,
                             Action<AnimationClip, float> write, float lo, float hi)
        {
            var layer = NewLayer(ctrl, tag);
            var st = layer.stateMachine.AddState(tag);
            layer.stateMachine.defaultState = st;
            var tree = new BlendTree
            {
                name = tag + "Tree",
                blendType = BlendTreeType.Simple1D,
                blendParameter = param,
                useAutomaticThresholds = false,
            };
            AssetDatabase.AddObjectToAsset(tree, ctrl);
            for (var i = 0; i < 2; i++)
            {
                var clip = MakeClip(tag + i, write, i == 0 ? lo : hi);
                tree.AddChild(clip, i == 0 ? 0f : 1f);
            }
            st.motion = tree;
        }

        /// <summary>一条 **Bool 两状态**层（开关用；VRChat 里 Bool 只占 1 bit）。</summary>
        static void AddBoolLayer(AnimatorController ctrl, string param, string tag, bool defaultOn,
                                 Action<AnimationClip, float> write)
        {
            var layer = NewLayer(ctrl, tag);
            var sm = layer.stateMachine;
            var off = sm.AddState(tag + "Off");
            var on = sm.AddState(tag + "On");
            off.motion = MakeClip(tag + "Off", write, 0f);
            on.motion = MakeClip(tag + "On", write, 1f);
            sm.defaultState = defaultOn ? on : off;
            var t1 = off.AddTransition(on);
            t1.hasExitTime = false; t1.duration = 0f; t1.AddCondition(AnimatorConditionMode.If, 0f, param);
            var t2 = on.AddTransition(off);
            t2.hasExitTime = false; t2.duration = 0f; t2.AddCondition(AnimatorConditionMode.IfNot, 0f, param);
        }

        static AnimatorControllerLayer NewLayer(AnimatorController ctrl, string tag)
        {
            var layer = new AnimatorControllerLayer
            {
                name = NTVrcParameterBuilder.LayerPrefix + tag,
                stateMachine = new AnimatorStateMachine { name = tag + "SM" },
                defaultWeight = 1f,     // ⛔ 必须 1
            };
            ctrl.AddLayer(layer);
            return layer;
        }

        static AnimationClip MakeClip(string name, Action<AnimationClip, float> write, float v)
        {
            var clip = new AnimationClip { name = name, frameRate = 60f, legacy = false };
            write(clip, v);
            AssetDatabase.CreateAsset(clip, Folder + "/" + name + ".anim");
            return clip;
        }

        static void AddMat(AnimationClip clip, GameObject root, Renderer rd, string prop, float v)
        {
            if (rd == null) return;
            var rel = AnimationUtility.CalculateTransformPath(rd.transform, root.transform);
            var b = EditorCurveBinding.FloatCurve(rel, rd.GetType(), "material." + prop);
            AnimationUtility.SetEditorCurve(clip, b, AnimationCurve.Constant(0f, 1f / 60f, v));
        }

        static void AddField(AnimationClip clip, string relPath, Type scriptType, string field, float v)
        {
            if (scriptType == null) return;
            var b = new EditorCurveBinding { path = relPath, type = scriptType, propertyName = field };
            AnimationUtility.SetEditorCurve(clip, b, AnimationCurve.Constant(0f, 1f / 60f, v));
        }

        static void EnsureFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return;
            var parent = folder.Substring(0, folder.LastIndexOf('/'));
            var leaf = folder.Substring(folder.LastIndexOf('/') + 1);
            if (!AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder("Assets", parent.Substring("Assets/".Length));
            AssetDatabase.CreateFolder(parent, leaf);
        }

        static Type FindType(string full)
        {
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                var t = a.GetType(full, false);
                if (t != null) return t;
            }
            return null;
        }
    }
}
