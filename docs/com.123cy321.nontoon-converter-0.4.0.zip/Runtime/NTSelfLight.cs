using UnityEngine;

namespace NonToonTools
{
    // [NT-TOOL] 「自有光源」配置组件。挂在 avatar（或任意根节点）上。
    //
    // 重要：运行时**没有任何行为**。它只是用来保存「指定哪一盏光源」+ 烘焙参数；
    // 真正的数据全部写进材质属性，烘焙完可以把它删掉。
    // 之所以不做成真的挂一盏 Unity Light：VRChat 性能等级 PC 上要求 Lights = 0
    // （只有 Poor 允许 1），而且真实光会照亮周围世界与别的玩家，做不到"只照自己"。
    [AddComponentMenu("NonToon/自有光源 Self Light")]
    public sealed class NTSelfLight : MonoBehaviour
    {
        [Tooltip("指定的光源：烘焙时把它的方向/颜色/强度写进材质。不会真的产生一盏实时光。")]
        public Light lightSource;

        [Tooltip("只由这一路光照亮：忽略世界光与环境光，avatar 在任何世界里长得都一样")]
        public bool onlyThisLight;

        [Tooltip("光源颜色（可覆盖 lightSource 的颜色）")]
        public Color color = Color.white;

        [Range(0f, 4f)]
        [Tooltip("光源强度")]
        public float intensity = 1f;

        [Range(64, 1024)]
        [Tooltip("自阴影贴图分辨率。256 通常够用，512 更细腻但烘焙更慢")]
        public int shadowResolution = 256;

        [Tooltip("PCSS 软阴影：先求遮挡物平均深度，再按半影大小做变半径 PCF（固定 8 + 12 次采样）。\n关掉就是 1 次采样的硬阴影，最省算力。")]
        public bool pcss = true;

        [Range(0f, 1f)]
        [Tooltip("阴影柔度：越大半影越宽、边越软。只在开启 PCSS 时有效")]
        public float softness = 0.5f;

        [Range(0f, 1f)]
        [Tooltip("阴影浓度。1 = 该黑的地方就黑，0 = 完全没有自阴影")]
        public float shadowDensity = 1f;

        [Range(0f, 1f)]
        [Tooltip("阴影硬化：把 PCSS 的软边压成硬边（动画风）。0 = 保持软边")]
        public float shadowClamp = 0f;

        [Range(0f, 50f)]
        [Tooltip("阴影距离：离相机超过该距离就关闭自阴影（省算力，也避免远处噪点）。0 = 不限制")]
        public float shadowDistance = 10f;

        [Range(0f, 1f)]
        [Tooltip("阴影强度。0 = 关闭自阴影（只用私有光）")]
        public float shadowStrength = 1f;

        [Range(0f, 0.2f)]
        [Tooltip("阴影偏移：出现自阴影痤疮（条纹状噪点）时调大")]
        public float shadowBias = 0.02f;

        [Tooltip("接收遮罩：逐像素控制「哪里接收自阴影」，白色 = 正常接收阴影（对应 PCSS4VRC 的 ReceiveMask）")]
        public Texture2D receiveMask;

        [Range(0, 7)]
        [Tooltip("接收遮罩使用哪个通道：0=R 1=G 2=B 3=A 4=1-R 5=1-G 6=1-B 7=1-A")]
        public int receiveMaskChannel = 3;

        [Range(0f, 1f)]
        [Tooltip("接收遮罩强度：0 = 忽略遮罩，1 = 完全按遮罩")]
        public float receiveMaskStrength = 1f;

        [HideInInspector]
        public Texture2D bakedShadowMap;

        // 世界空间、指向光源的方向（与 Shader 里的 _SelfLightDirection 同义）
        public Vector3 Direction
        {
            get { return lightSource != null ? -lightSource.transform.forward : Vector3.up; }
        }
    }
}
