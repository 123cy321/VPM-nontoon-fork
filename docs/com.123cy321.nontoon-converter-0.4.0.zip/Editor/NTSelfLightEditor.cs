using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NonToonTools
{
    // [NT-TOOL] NTSelfLight 的检视面板：把「指定的光源」写进材质 + 烘焙自阴影。
    //
    // 注意 Int 属性必须用 SetInteger：NonToon 的 SC_uint / ShaderLab Int 属性用 SetFloat 写是**静默无效**的
    // （这个坑在材质转换器那边踩过一次：_ShadowColorEnable 写进去变 0）。
    //
    // [NT-L10N] 字段标签也自己画，因为 Unity 默认是用 C# 字段名 nicify 出来的英文。
    [CustomEditor(typeof(NTSelfLight))]
    public sealed class NTSelfLightEditor : Editor
    {
        private string lastSummary;
        private bool showAdvanced;

        public override void OnInspectorGUI()
        {
            var settings = (NTSelfLight)target;
            using var _ = new EditorGUI.ChangeCheckScope();

            EditorGUILayout.LabelField("光源", EditorStyles.boldLabel);
            settings.lightSource = (Light)EditorGUILayout.ObjectField(new GUIContent("光源 Light Source", "烘焙时读取它的方向/颜色/强度。不会真的把它挂到 avatar 上。"), settings.lightSource, typeof(Light), true);
            settings.onlyThisLight = EditorGUILayout.Toggle(new GUIContent("只由它照亮", "忽略世界光与环境光，avatar 在任何世界里长得都一样"), settings.onlyThisLight);
            settings.color = EditorGUILayout.ColorField(new GUIContent("光源颜色", "可覆盖 Light Source 的颜色"), settings.color);
            settings.intensity = EditorGUILayout.Slider(new GUIContent("光源强度"), settings.intensity, 0f, 4f);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("自阴影", EditorStyles.boldLabel);
            settings.pcss = EditorGUILayout.Toggle(new GUIContent("PCSS 软阴影", "先求遮挡物平均深度，再按半影做变半径 PCF（固定 8 + 12 次采样）。\n关掉 = 1 次采样的硬阴影，最省算力。"), settings.pcss);
            using (new EditorGUI.DisabledScope(!settings.pcss))
            {
                settings.softness = EditorGUILayout.Slider(new GUIContent("柔度 Softness"), settings.softness, 0f, 1f);
                settings.shadowClamp = EditorGUILayout.Slider(new GUIContent("硬化 Shadow Clamp", "把软边压成硬边（动画风），0 = 保持软边"), settings.shadowClamp, 0f, 1f);
            }
            settings.shadowDensity = EditorGUILayout.Slider(new GUIContent("浓度 Density"), settings.shadowDensity, 0f, 1f);
            settings.shadowStrength = EditorGUILayout.Slider(new GUIContent("强度 Strength"), settings.shadowStrength, 0f, 1f);
            settings.shadowDistance = EditorGUILayout.Slider(new GUIContent("阴影距离", "离相机超过该距离就关闭自阴影。0 = 不限制"), settings.shadowDistance, 0f, 50f);
            settings.receiveMask = (Texture2D)EditorGUILayout.ObjectField(new GUIContent("接收遮罩 Receive Mask", "逐像素控制哪里接收自阴影，白色 = 正常接收"), settings.receiveMask, typeof(Texture2D), false);
            using (new EditorGUI.DisabledScope(settings.receiveMask == null))
            {
                settings.receiveMaskChannel = EditorGUILayout.Popup(new GUIContent("遮罩通道"), settings.receiveMaskChannel, new[] { "R", "G", "B", "A", "1-R", "1-G", "1-B", "1-A" });
                settings.receiveMaskStrength = EditorGUILayout.Slider(new GUIContent("遮罩强度"), settings.receiveMaskStrength, 0f, 1f);
            }

            showAdvanced = EditorGUILayout.Foldout(showAdvanced, "高级（烘焙 / 偏移）");
            if (showAdvanced)
            {
                EditorGUI.indentLevel++;
                var resolutions = new[] { 64, 128, 256, 512, 1024 };
                var resolutionNames = new[] { "64", "128", "256", "512", "1024" };
                var resolutionIndex = Mathf.Max(0, System.Array.IndexOf(resolutions, settings.shadowResolution));
                resolutionIndex = EditorGUILayout.Popup(new GUIContent("烘焙分辨率", "256 通常够用，512 更细腻但烘焙更慢"), resolutionIndex, resolutionNames);
                settings.shadowResolution = resolutions[Mathf.Clamp(resolutionIndex, 0, resolutions.Length - 1)];
                settings.shadowBias = EditorGUILayout.Slider(new GUIContent("阴影偏移 Bias", "出现自阴影痤疮（条纹状噪点）时调大"), settings.shadowBias, 0f, 0.2f);
                EditorGUI.indentLevel--;
            }

            if (GUI.changed)
            {
                EditorUtility.SetDirty(settings);
                // 参数改了但还没烘焙时，也允许直接同步到材质
                if (settings.lightSource != null) Apply(settings, CollectTargetMaterials(settings), null, false);
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("操作", EditorStyles.boldLabel);

            if (settings.lightSource == null)
                EditorGUILayout.HelpBox("请先指定一盏光源（Light Source）。烘焙时只读取它的方向/颜色，不会真的把它挂到 avatar 上。", MessageType.Warning);

            var materials = CollectTargetMaterials(settings);
            EditorGUILayout.LabelField("层级里的 NonToon 材质", materials.Count.ToString());

            using (new EditorGUI.DisabledScope(settings.lightSource == null || materials.Count == 0))
            {
                if (GUILayout.Button("只同步参数（不烘焙）", GUILayout.Height(22)))
                    Apply(settings, materials, null, true);
                if (GUILayout.Button("烘焙自阴影并写入材质", GUILayout.Height(26)))
                {
                    var result = NTSelfShadowBaker.Bake(settings.lightSource, settings.GetComponentsInChildren<Renderer>(true), settings.shadowResolution, "Assets/NonToonSelfLight");
                    settings.bakedShadowMap = result.map;
                    EditorUtility.SetDirty(settings);
                    Apply(settings, materials, result, true);
                    lastSummary = "烘焙完成：" + result.map.name + "（" + result.texels + " 像素，命中 " + result.hits + "，" + result.meshCount + " 个网格）\n阴影贴图：" + result.path;
                }
            }

            if (!string.IsNullOrEmpty(lastSummary))
                EditorGUILayout.HelpBox(lastSummary, MessageType.Info);

            EditorGUILayout.HelpBox(
                "说明：本组件运行时没有任何行为 —— 所有数据都写进材质属性，烘焙完可以把它删掉。\n" +
                "之所以不用真实光源：VRChat 性能等级 PC 上要求 Lights = 0（只有 Poor 允许 1），" +
                "而且真实光会照亮周围世界与别的玩家，做不到「只照自己」。\n" +
                "PCSS 软阴影与「阴影距离」的思路参考 nHaruka 的 PCSS4VRC（真实影システム），" +
                "但换成不需要实时光的着色器实现：固定 8 + 12 次采样，Quest 也能用。\n" +
                "改了姿态/网格/光源方向后需要重新烘焙。",
                MessageType.None);
        }

        private static List<Material> CollectTargetMaterials(NTSelfLight settings)
        {
            var result = new HashSet<Material>();
            foreach (var renderer in settings.GetComponentsInChildren<Renderer>(true))
                foreach (var material in renderer.sharedMaterials)
                    if (material != null && material.HasProperty("_UseSelfLight")) result.Add(material);
            return result.ToList();
        }

        private static void Apply(NTSelfLight settings, List<Material> materials, NTSelfShadowBaker.Result baked, bool log)
        {
            var light = settings.lightSource;
            foreach (var material in materials)
            {
                SetNumber(material, "_UseSelfLight", 1f);
                SetNumber(material, "_SelfLightOnly", settings.onlyThisLight ? 1f : 0f);
                material.SetColor("_SelfLightColor", settings.color);
                SetNumber(material, "_SelfLightIntensity", settings.intensity);
                material.SetVector("_SelfLightDirection", settings.Direction);
                SetNumber(material, "_SelfLightShadowStrength", settings.shadowStrength);
                SetNumber(material, "_SelfLightShadowBias", settings.shadowBias);

                // [NT-FEAT 10] 类 PCSS 软阴影相关参数
                SetNumber(material, "_SelfLightPCSS", settings.pcss ? 1f : 0f);
                SetNumber(material, "_SelfLightSoftness", settings.softness);
                SetNumber(material, "_SelfLightDensity", settings.shadowDensity);
                SetNumber(material, "_SelfLightClamp", settings.shadowClamp);
                SetNumber(material, "_SelfLightDistance", settings.shadowDistance);
                if (material.HasProperty("_SelfLightReceiveMask"))
                {
                    material.SetTexture("_SelfLightReceiveMask", settings.receiveMask);
                    SetNumber(material, "_SelfLightReceiveMaskChannel", settings.receiveMaskChannel);
                    SetNumber(material, "_SelfLightReceiveMaskStrength", settings.receiveMask == null ? 0f : settings.receiveMaskStrength);
                }

                if (baked != null && baked.map != null)
                {
                    material.SetTexture("_SelfLightShadowMap", baked.map);
                    material.SetVector("_SelfLightOrigin", baked.origin);
                    material.SetVector("_SelfLightRight", baked.right);
                    material.SetVector("_SelfLightUp", baked.up);
                    material.SetVector("_SelfLightForward", baked.forward);
                    SetNumber(material, "_SelfLightHalfX", baked.halfX);
                    SetNumber(material, "_SelfLightHalfY", baked.halfY);
                    SetNumber(material, "_SelfLightNear", baked.near);
                    SetNumber(material, "_SelfLightFar", baked.far);
                    // PCSS 需要知道一个纹素有多大（用烘焙分辨率算）
                    SetNumber(material, "_SelfLightShadowTexels", baked.resolution);
                }
                else if (settings.bakedShadowMap != null)
                {
                    material.SetTexture("_SelfLightShadowMap", settings.bakedShadowMap);
                }

                EditorUtility.SetDirty(material);
            }
            AssetDatabase.SaveAssets();
            if (!log) return;
            Debug.Log("[NTSelfLight] 已写入 " + materials.Count + " 个材质"
                + (light != null ? "（光源 " + light.name + "，方向 " + settings.Direction.ToString("F3") + "）" : "")
                + (baked != null ? "，并烘焙了自阴影贴图 " + (baked.map != null ? baked.map.name : "<失败>") : ""));
        }

        // Int 属性走 SetInteger，其余走 SetFloat
        private static void SetNumber(Material material, string property, float value)
        {
            if (string.IsNullOrEmpty(property) || !material.HasProperty(property)) return;
            var index = material.shader.FindPropertyIndex(property);
            if (index >= 0 && material.shader.GetPropertyType(index) == UnityEngine.Rendering.ShaderPropertyType.Int)
                material.SetInteger(property, Mathf.RoundToInt(value));
            else material.SetFloat(property, value);
        }
    }
}
