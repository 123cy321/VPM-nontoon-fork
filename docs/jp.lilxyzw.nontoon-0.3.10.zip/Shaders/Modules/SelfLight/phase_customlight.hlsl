// [NT-FEAT 7 / NT-FEAT 15 / NT-FEAT 18] SelfLight —— 叠加通路（_SelfLightOnly = 0）。
//
// ── 为什么必须区分 pass（0.3.5 修的真 bug）────────────────────────────────────
// birp.hlsl 的 frag 被 **ForwardBase / ForwardAdd / Outline / OutlineAdd 共用**，
// 它们都会调 SCCalculateAllLights → 我们的 customlight 相位。于是"自有光"会在
// **每一个 forward pass 里各加一遍**：地图里有 N 盏像素光时，avatar 的自有光被加 N 次 → 过曝。
// 自有光只在 **base pass** 加一次（Outline 也是 ForwardBase 标签，所以描边同样受光，一致）。
//
// 「只由它照亮」的排他通路在 phase_modifylight.hlsl。
//
// 为什么不做成真实 Unity Light（调研结论，官方出处）：
//   · VRChat 性能等级：PC 上 Excellent / Good / Medium 都要求 Lights = 0，只有 Poor 才允许 1。
//   · 真实光会**照亮周围世界与别的玩家**，做不到"只照自己"。
//   · Quest 端实时光基本不可用。
//   （不在意性能等级的话，工具包里有独立的 Avatar 光源插件，本组件也有「实时光源」模式。）
//
// 自阴影 / 色温 / 环境匹配都在 includes.hlsl 的宏里，与排他通路共用。
#if !defined(UNITY_PASS_FORWARDADD)
if (_UseSelfLight && _SelfLightOnly < 0.5)
{
    half3 selfL;
    NTSELFLIGHT_DIR(selfL, vertex.position)

    half selfShadow = 1;
    NTSELFSHADOW(selfShadow, vertex.position, sd.uv)

    // 把地图的灯"探"出来（环境匹配用）：SH 的 L0 项；光照贴图工程里退化成主光颜色
    half3 ntSelfAmbient = 0;
#if !defined(LIGHTMAP_ON) && UNITY_SHOULD_SAMPLE_SH
    ntSelfAmbient = half3(unity_SHAr.w, unity_SHAg.w, unity_SHAb.w);
#endif
    half3 ntSelfWorldColor;
    NTSELFLIGHT_WORLD_COLOR(ntSelfWorldColor, ntSelfAmbient)

    half3 selfColor;
    NTSELFLIGHT_COLOR(selfColor, ntSelfWorldColor)

    // [NT-FEAT 18] 阴影颜色：把阴影处的光染成 Shadow Color（默认黑 = 与旧行为完全一致）
    half3 ntSelfShadeTint = lerp(_SelfLightShadowColor.rgb, half3(1, 1, 1), selfShadow);

    half3 selfTerm = selfColor * (_SelfLightIntensity * saturate(dot(sd.N, selfL)) * selfShadow) * ntSelfShadeTint;
    lightSum.color += selfTerm;
}
#endif

// ═══════════════════════════════════════════════════════════════════════════
// [NT-FEAT 20] ⑥ 实时自阴影（PCSS over 我们自己渲染的深度图）—— 钩子
//
// ⚠️⚠️ 为什么钩在 **customlight**，而不是 `__SC_PHASE_light__`（血泪教训，别改回去）
//   同样一段"读取 `_SelfLightRt*` 材质属性"的代码，放在 `__SC_PHASE_light__`
//   （= `SCCalculateLight()` 的**函数体第一行**）会让 FXC 报 **82 条**
//   `variable 'X' used without having been completely initialized` ——
//   而且**连 `_BacklightRange` / `_jp_lilxyzw_nontoon_specular_SpecularF0`
//   这种毫不相干的属性一起报**，NonToon 与 NonToonFur 双双变洋红错误着色器
//   （装置 A EXIT=1）。
//   装置 A 二分的三条硬证据（脚本 `_notes/bisect-6.sh`、变体 `/tmp/phase-v1.hlsl`）：
//     · `__SC_PHASE_light__` + **不读任何材质属性**（全硬编码局部量） → **0 条** ✅
//     · `__SC_PHASE_light__` + 读材质属性                          → **82 条** ❌
//     · `__SC_PHASE_customlight__` + 读材质属性（④ 一直这么干）     → **0 条** ✅
//   ⇒ **结论（写死）：凡是要读材质属性，一律钩在 frag 侧的相位
//     （customlight / modifylight / shade / add / postpixel）；
//     `__SC_PHASE_light__` 里只允许出现参数与硬编码常量。**
//
// ── 语义 ─────────────────────────────────────────────────────────────────
//   本相位在 `SCCalculateAllLights()` 里、**光源循环之后**（`birp_lighting.hlsl:109`），
//   此时 `lightSum.color` = "本 pass 的直接光总和"。只对 `FORWARDADD + SPOT` 生效
//   ⇒ 正好是那盏附加聚光灯的贡献。乘在 `lightSum.color` 上、**不动 `env`**
//   ⇒ 环境光不会被我们误压暗。
//
// ── 为什么用"乘法"而不是把 Unity 的阴影换掉 ─────────────────────────────
//   早期做法想从 `light.color` 里反推 Unity 的阴影系数，实测不可能（阴影处落在
//   0.38~0.5，混着逐像素顶点光系数）；比值法在 `hard = 0` 的内侧还会爆掉。
//   ⇒ 组件把这盏灯的 Unity 实时阴影关掉（`LightShadows.None`），我们直接乘自己的
//     PCSS。副作用是好的：**省掉该灯全部 ShadowCaster draw call**。
// ── 为什么门控是 `SPOT` + "光位置对上"，而不是 `UNITY_PASS_FORWARDADD` ──────
//   ⚠️ 踩过的坑：BiRP 里**最亮的那盏光会被放进 base pass**（当作 main light）。
//   试验场景里只有一盏 Spot（方向光被关掉）时，Unity 把它渲在 **ForwardBase**，
//   于是 `UNITY_PASS_FORWARDADD` 根本没定义、这段代码被整体编译掉 ⇒
//   "PCSS 完全没效果"（装置 C 实测：pcss=1 与 pcss=0 逐像素相同）。
//   所以门控改成：
//     · `SPOT`（base pass 的 `multi_compile_fwdbase` 与 add pass 的
//       `multi_compile_fwdadd_fullshadows` 都含 SPOT 关键字）
//     · 且 `_WorldSpaceLightPos0` 指向的正是**我们那盏灯**（两个 pass 里它分别
//       是 main light / add light 的位置），用位置比对把"别的聚光灯"排除掉。
//   这样 base / ForwardAdd / Outline / OutlineAdd 四个 pass 都能各自正确地作用，
//   而且我们乘的是**本 pass 的直接光总和** `lightSum.color`，不会碰 `env`。
#if defined(SPOT)
if (_SelfLightRtPcss > 0.5 &&
    distance(_WorldSpaceLightPos0.xyz, _SelfLightRtLightPos.xyz) < 0.05)
{
    float ntRtSpan = max(_SelfLightRtShadowFar - _SelfLightRtShadowNear, 1e-4);
    float ntRtBias = _SelfLightRtBias / ntRtSpan;      // 米 → 归一化深度

    // 影子坐标完全由**我们自己的** worldToShadow 决定（C# 用同一组矩阵渲染深度图）
    float ntRtValid;
    float2 ntRtUV = NTRTS_ProjectUV(_SelfLightRtW2S0, _SelfLightRtW2S1,
                                    _SelfLightRtW2S2, _SelfLightRtW2S3,
                                    vertex.position, ntRtValid);

    // 本片元的线性深度（0..1，越大越远），与深度图同一约定。
    // 用 `distance` 而不是投影 z：深度图里存的也是**径向距离**，两边同尺度。
    float ntRtDist = distance(vertex.position, _SelfLightRtLightPos.xyz);
    float ntRtFragDepth = saturate((ntRtDist - _SelfLightRtShadowNear) / ntRtSpan);

    // 只有落在光锥内（uv ∈ [0,1] 且在光源前方）才处理；锥外本来就照不到
    if (ntRtValid > 0.5 && ntRtUV.x >= 0.0 && ntRtUV.x <= 1.0 && ntRtUV.y >= 0.0 && ntRtUV.y <= 1.0)
    {
        // per-pixel 旋转：用 IGN（比 frac(sin(...)) 少对角条纹/颗粒）。按**深度图纹素**取，
        // 这样去带图案与阴影图分辨率对齐，换分辨率不会突然出现条纹。
        float ntRtRnd = NTRTS_IGN(ntRtUV * max(_SelfLightRtShadowTexels, 1.0));
        float ntRtShadow = NTRTS_PCSS(ntRtUV, ntRtFragDepth, ntRtRnd,
                                      _SelfLightRtShadowTexels, ntRtBias,
                                      _SelfLightRtSoftness, _SelfLightRtPcssScale,
                                      _SelfLightRtQuality,
                                      _SelfLightRtShadowFloor);
        lightSum.color *= ntRtShadow;
    }
}

#endif
