#ifndef NT_SELFLIGHT_SHADOW_INCLUDED
#define NT_SELFLIGHT_SHADOW_INCLUDED

// [NT-FEAT 7/10/15] SelfLight 的公共片段。
//
// 为什么用宏而不是函数：phase_*.hlsl 的内容会被 ShaderCore **原样拼进 frag() 内部**，
// 函数里不能再定义函数。而这个 includes.hlsl 会被拼到 include 区，宏在展开处（frag 内部）
// 才解析 SCSample / NTMaskValue / 材质属性，所以放在这里定义、在多个 phase 里展开都成立。
//
// [NT-FIX 0.3.8] 自阴影的取样点**必须夹到「纹素内部」**（blocker 与 filter 两处）：
//   ShaderCore 的 SC_SamplerState 展开成裸 `SamplerState`（没有 filter / address 声明），
//   实测（Unity 2022.3.22f1 / D3D11）深度图走的是**点采样 + Repeat**，而且**与贴图导入设置无关**
//   —— 烘焙器写进去的 `wrapMode = Clamp` 对采样不生效。
//   不夹时，螺旋偏移一旦越过包围盒边界就会读到深度图**对面**的纹素，表现有两种：
//     · 对面是背景（远）→ 贴边一圈的半影被冲淡（实测遮挡 1.000 → 0.642，漏光 36%）
//     · 对面是几何（近）→ 凭空多出一条假阴影（实测亮度 0.93 → 0.000，约 7 纹素宽）
//   注意：**只夹到 [0,1] 不够** —— Repeat 的有效区间是 [0,1)，u = 1.0 会被映射回纹素 0，
//   于是右边界依旧漏光（实测仍是 0.642；左边界倒是好了）。必须夹到
//   `[0.5 纹素, 1 - 0.5 纹素]`，落点才是首/末纹素，与 Clamp 语义一致。
//   夹完之后行为由代码决定，不再依赖平台 / 采样器绑定 / 用户换图（Quest 上同类风险一并消除）。
//   实测装置与像素证据：`unity/_notes/probes/NTPcssProbe.cs` + `_notes/evidence/pcss/`。

// [NT-FIX 0.3.9] 半影的世界宽度必须与**烘焙分辨率**无关（P2）。
//   背景：半径以「纹素」定义，而一个纹素的世界尺寸 = `2·halfX / _SelfLightShadowTexels`
//   ⇒ 世界半径 ∝ 1/分辨率。实测同一场景 256²→512² 半影世界尺度只剩 71%、1024² 只剩 57%。
//   为什么不是"半径 ×s"（线性的、看起来最自然的修法）：**实际半影宽度对纹素半径是超线性的**。
//   判别实验（同一张 256² 贴图，只改取样足迹，贴图内容一点没变）：
//     足迹 4.4 纹素 → 7.0 px ；8.8 纹素 → 28.0 px ；17.6 纹素 → 49.0 px
//   ⇒ 宽度 ≈ `R^1.55`，而盘状核的理论值只有 `1.6R`（小半径处只实现一半）。
//   所以线性的 ×s 会把世界尺度从 71% 矫枉过正到 143%（实测），tap 数 ×1/×s/×s² 都改变不了。
//   修法：按 `g(s) = s^p`、`p = 1/1.55 ≈ 0.65` 换算半径与上下限，使世界尺度守恒。
//   锚点性质：256² 时 `s = 1 ⇒ g = 1`，与旧行为**逐像素一致** ⇒ 存量 avatar（默认 256²）零变化。
//   回归门禁：`NTPcssProbe` 的【P2】断言（256² vs 512² 世界尺度须落在 85%~120%）。

// ---------------------------------------------------------------------------
// 自阴影系数：1 = 完全受光，0 = 完全在阴影里。
// 用法：NTSELFSHADOW(outShadow, positionWS, uv)
// ---------------------------------------------------------------------------
#ifndef NTSELFSHADOW
#define NTSELFSHADOW(outShadow, positionWS, uv) \
{ \
    outShadow = 1; \
    if (_SelfLightShadowStrength > 0.001) \
    { \
    float3 ntSD_Rel = (positionWS) - _SelfLightOrigin.xyz; \
    float2 ntSD_UV = float2(dot(ntSD_Rel, _SelfLightRight.xyz), dot(ntSD_Rel, _SelfLightUp.xyz)); \
    ntSD_UV = ntSD_UV / float2(max(1e-5, _SelfLightHalfX), max(1e-5, _SelfLightHalfY)) * 0.5 + 0.5; \
    float ntSD_Depth = (dot(ntSD_Rel, _SelfLightForward.xyz) - _SelfLightNear) / max(1e-5, _SelfLightFar - _SelfLightNear); \
    bool ntSD_InBox = ntSD_UV.x > 0 && ntSD_UV.x < 1 && ntSD_UV.y > 0 && ntSD_UV.y < 1 && ntSD_Depth > 0 && ntSD_Depth < 1; \
    bool ntSD_InRange = _SelfLightDistance <= 0.0001 || distance(_WorldSpaceCameraPos, positionWS) <= _SelfLightDistance; \
    if (ntSD_InBox && ntSD_InRange) \
    { \
        float2 ntSD_Texel = (1.0 / max(_SelfLightShadowTexels, 8.0)).xx; \
        /* [NT-FIX 0.3.8] 取样点必须夹到「纹素内部」而不是 [0,1]：                            */ \
        /*   Repeat 寻址下 u = 1.0 会被映射回纹素 0（Repeat 的有效区间是 [0,1)），           */ \
        /*   所以只夹到 [0,1] 时，越界的取样仍然会读到对面那一列 —— 实测右边界依旧漏光 36%。 */ \
        /*   夹到 [0.5 纹素, 1 - 0.5 纹素] 后，落点必定是首/末纹素，与 Clamp 语义一致。      */ \
        float2 ntSD_TapMin = ntSD_Texel * 0.5; \
        float2 ntSD_TapMax = float2(1.0, 1.0) - ntSD_Texel * 0.5; \
        float ntSD_Rot = frac(sin(dot(ntSD_UV, float2(12.9898, 78.233))) * 43758.5453) * 6.2831853; \
        float ntSD_RotSin = sin(ntSD_Rot); \
        float ntSD_RotCos = cos(ntSD_Rot); \
        if (_SelfLightPCSS > 0.5) \
        { \
            int ntSD_BlockerBase = _SelfLightPCSSQuality < 0.5 ? 8 : (_SelfLightPCSSQuality < 1.5 ? 12 : (_SelfLightPCSSQuality < 2.5 ? 20 : 32)); \
            int ntSD_FilterBase = _SelfLightPCSSQuality < 0.5 ? 12 : (_SelfLightPCSSQuality < 1.5 ? 24 : (_SelfLightPCSSQuality < 2.5 ? 40 : 64)); \
            float ntSD_MaxRadius = ntSD_FilterBase >= 40 ? 48.0 : 24.0; \
            /* [NT-FIX 0.3.9] 纹素 → 世界尺度的换算。指数 0.8 是**实测标定**出来的（见文件头）：    */
            /*   实际半影宽度对纹素半径是超线性的（≈R^1.55），线性 ×s 会矫枉过正（71%→143%）；  */
            /*   又因为下面同时补了 tap 数（超出"半径"之外的额外影响），标定值落在 0.8。        */ \
            float ntSD_ResScale = max(_SelfLightShadowTexels, 8.0) / 256.0; \
            float ntSD_ResGain = pow(ntSD_ResScale, 0.8); \
            /* [NT-FIX 0.3.9] tap 数也要补：1024² 下 12 个 tap 在大半径上已经"糊不动"（实测半径 4.4→17.6 */
            /*   纹素，半影只从 4.0 涨到 5.0 px，饱和了）。tap 按 s² 补（面积密度守恒）并把总数封顶在 */ \
            /*   64/32（= 极高档的预算，避免 1024² 以上把采样炸掉）。256² 时 s² = 1 ⇒ 与旧行为一致。 */ \
            int ntSD_TapScale = (int)clamp(floor(ntSD_ResScale * ntSD_ResScale + 0.5), 1.0, 16.0); \
            int ntSD_BlockerTaps = min(ntSD_BlockerBase * ntSD_TapScale, 32); \
            int ntSD_FilterTaps = min(ntSD_FilterBase * ntSD_TapScale, 64); \
            float ntSD_BlockerSum = 0; \
            float ntSD_BlockerCount = 0; \
            for (int ntSD_BI = 0; ntSD_BI < ntSD_BlockerTaps; ntSD_BI++) \
            { \
                float ntSD_BF = (ntSD_BI + 0.5) / (float)ntSD_BlockerTaps; \
                float ntSD_BA = ntSD_BI * 2.39996323 + ntSD_Rot; \
                float2 ntSD_BO = float2(cos(ntSD_BA), sin(ntSD_BA)) * sqrt(ntSD_BF) * ntSD_Texel * 8.0; \
                float ntSD_BZ = _SelfLightShadowMap.SampleLevel(sampler_BaseTexture, clamp(ntSD_UV + ntSD_BO, ntSD_TapMin, ntSD_TapMax), 0).r; \
                if (ntSD_BZ < ntSD_Depth - _SelfLightShadowBias) { ntSD_BlockerSum += ntSD_BZ; ntSD_BlockerCount += 1; } \
            } \
            if (ntSD_BlockerCount < 0.5) \
            { \
                outShadow = 1; \
            } \
            else \
            { \
                float ntSD_AvgBlocker = ntSD_BlockerSum / ntSD_BlockerCount; \
                float ntSD_Penumbra = (ntSD_Depth - ntSD_AvgBlocker) / max(ntSD_AvgBlocker, 1e-4) * _SelfLightSoftness; \
                /* [NT-FIX 0.3.9] 半径与上下限按 g(s) 换算 ⇒ 世界尺度半影与烘焙分辨率无关 */ \
                float ntSD_Radius = clamp(ntSD_Penumbra * 0.5 * ntSD_ResGain, 1.5 * ntSD_ResGain, ntSD_MaxRadius * ntSD_ResGain); \
                float ntSD_Sum = 0; \
                for (int ntSD_PI = 0; ntSD_PI < ntSD_FilterTaps; ntSD_PI++) \
                { \
                    float ntSD_PF = (ntSD_PI + 0.5) / (float)ntSD_FilterTaps; \
                    float ntSD_PA = ntSD_PI * 2.39996323 + ntSD_Rot; \
                    float2 ntSD_Local = float2(cos(ntSD_PA), sin(ntSD_PA)) * sqrt(ntSD_PF) * ntSD_Radius; \
                    float2 ntSD_PO = float2(ntSD_Local.x * ntSD_RotCos - ntSD_Local.y * ntSD_RotSin, ntSD_Local.x * ntSD_RotSin + ntSD_Local.y * ntSD_RotCos) * ntSD_Texel; \
                    float ntSD_PZ = _SelfLightShadowMap.SampleLevel(sampler_BaseTexture, clamp(ntSD_UV + ntSD_PO, ntSD_TapMin, ntSD_TapMax), 0).r; \
                    ntSD_Sum += (ntSD_Depth - _SelfLightShadowBias) > ntSD_PZ ? 0.0 : 1.0; \
                } \
                outShadow = ntSD_Sum / (float)ntSD_FilterTaps; \
            } \
        } \
        else \
        { \
            half ntSD_Occluder = _SelfLightShadowMap.SampleLevel(sampler_BaseTexture, ntSD_UV, 0).r; \
            outShadow = (ntSD_Depth - _SelfLightShadowBias) > ntSD_Occluder ? 0 : 1; \
        } \
        if (_SelfLightShadowStrength < 0.999) outShadow = lerp(1, outShadow, _SelfLightShadowStrength); \
        if (_SelfLightDensity < 0.999) outShadow = lerp(1, outShadow, _SelfLightDensity); \
        if (_SelfLightClamp > 0.001) \
        { \
            float ntSD_Contrast = lerp(1.0, 40.0, _SelfLightClamp); \
            outShadow = saturate((outShadow - 0.5) * ntSD_Contrast + 0.5); \
        } \
    } \
    } \
    if (_SelfLightShadowMaskStrength > 0.001)\
    {\
        half ntSD_SMask = NTMaskValue(SCSample(_SelfLightShadowMask, sampler_BaseTexture, uv), _SelfLightShadowMaskChannel);\
        outShadow *= lerp(1.0, ntSD_SMask, _SelfLightShadowMaskStrength);\
    }\
    if (_SelfLightReceiveMaskStrength > 0.001) \
    { \
        half ntSD_Mask = NTMaskValue(SCSample(_SelfLightReceiveMask, sampler_BaseTexture, uv), _SelfLightReceiveMaskChannel); \
        outShadow = lerp(1.0, outShadow, lerp(1.0, ntSD_Mask, _SelfLightReceiveMaskStrength)); \
    } \
}
#endif

// ═══════════════════════════════════════════════════════════════════════════
// [NT-FEAT 20] ⑥ 实时自阴影 —— 内核（PCSS over **我们自己渲染的**深度图）
//   只在 SPOT 下编译。
//
// ── 为什么必须自己渲染深度 ─────────────────────────────────────────────────
//   Unity 的逐光源阴影贴图在 D3D11 上只给出**比较采样器**（只返回 0/1），
//   拿不到遮挡物深度 ⇒ PCSS 的 blocker 搜索做不了。所有绕行方案都在实机上排除
//   （`_notes/续接-实时PCSS实现.md` §9.6 / §9.10）。
//   ⇒ 由 `NTSelfRealtimeShadow`（Runtime）用 `CommandBuffer + DrawRenderer` +
//     replacement shader `NonToon/NTRTDepth` 把遮挡物的**线性距离**渲进我们自己的
//     RenderTexture，再绑到 `_NTRTShadowMapRaw`。
//
// ── ★★ 2026-09-16 实机定位到的致命 bug：**投影矩阵从来没设过** ──────────────
//   旧 `RenderDepth()` 只做 `SetRenderTarget + DrawRenderer`，**没有**给 CommandBuffer
//   设 view / projection。`Graphics.ExecuteCommandBuffer` 不会替你建相机矩阵 ——
//   默认是**单位矩阵**。实机读回深度图的铁证（`_notes` 有记录）：
//     · 球体按**世界坐标正交投影**画成一个圆盘（质心 uv 0.339，而按聚光锥预测是 0.692）
//     · 接收面（Plane，顶点 ±5）因 clip 超出 [-1,1] 被**整体裁掉**，一张图 97% 是背景 1.0
//   ⇒ 深度图与接收面片元用的 uv **完全对不上** ⇒ `NTRTS_LitRaw` 恒为 1
//   ⇒ `pcss / hard ≡ 1` ⇒ 画面零变化。**这就是"PCSS 等于硬阴影"的真正根因**，
//   之前查的"自遮挡 / 半径太小 / 属性没绑"全是假线索。
//   修法：C# 侧显式构造 `view`/`proj` 并 `SetViewProjectionMatrices`，同时把**同一个**
//   `worldToShadow` 矩阵（`uvMat * gpuProj * view`）按 4 行传给着色器 ⇒ 投影与采样
//   由构造保证对齐，不再依赖任何 Unity 内部约定。
//
// ── 深度约定（与 NTRTDepth.shader / NTSelfRealtimeShadow 严格一致）──────────
//   `d = (到光源距离 - near) / (far - near)`，0..1、**越大越远**；背景清 1.0。
//   片元侧用 `distance(vertex.position, 灯位置)` 现算 —— 同一尺度、同一原点，
//   所以不需要任何 reversed-Z 归一化（这是"自己渲深度"相对 Unity 阴影贴图的好处）。
//
// ── 设计取自 UnityPCSS（TheMasonX，MIT）的公开设计要点 ──────────────────────
//   · 泊松盘采样（比黄金角螺旋各向同性、无螺旋纹）
//   · `penumbra = (z_frag - z_blocker) / z_blocker`（**比值式**，量纲无关）
//   · 半径 ∝ 遮挡距离、每像素随机旋转去带
//   注意：**行为要点可学，代码是重写的**（付费 PCSS4VRC 的规约禁止原样模仿与二次分发，
//   其资产/源码不得进入我们的包；我们的内核与它的底层不同）。
// ═══════════════════════════════════════════════════════════════════════════
#if defined(SPOT) && !defined(NTRTS_PCSS_KERNEL)
#define NTRTS_PCSS_KERNEL

// ═══ 内核**只用这一个全局量**，而且**只读**。═══════════════════════════════
// 由 C# 用 `Shader.SetGlobalTexture("_NTRTShadowMapRaw", rt)` 绑（不走材质属性 —— 见
// phase_light.hlsl 文件头：模块 includes 展开在属性声明之前，内核看不见 `SC_*` 属性，
// 而自声明 uniform 用 `Material.SetXxx` 绑不上）。
//
// ⛔ **千万不要**再在内核里加"由 phase 赋值的全局量"（例如 `float _NTRTS_Bias;` 再在 phase 里
//   `_NTRTS_Bias = _SelfLightRtBias;`）：实测（装置 A，`_notes/bisect-6.sh`）这会让 FXC 报
//   一连串 `variable 'X' used without having been completely initialized`
//   —— 而且**连毫不相干的属性**（`_BacklightRange`、`_jp_lilxyzw_nontoon_specular_SpecularF0` …）
//   一起报，整个 NonToon / NonToonFur 变成洋红错误着色器。
//   二分证据：只改 includes+properties（不写全局）→ **EXIT=0**；
//             加上 `_NTRTS_M0..3 = _SelfLightRtW2S0..3;` 这 4 行 → **EXIT=1**。
//   ⇒ **所有输入一律走函数参数**，由 phase 直接传（phase 在属性声明之后，看得见属性）。
//
// ⛔⛔ **`properties.hlsl` 里绝对不能有任何 `//` 注释行**（2026-09-16 又踩一次）：
//   ShaderCore 的 `SCProperty.FromFile` 是逐行解析的，任何匹配不上 `SC_*` 正则、
//   又不是空白的行都会 `throw new Exception("Property error. " + line)`
//   ⇒ **整个 .scshader 导入失败** ⇒ 没有 Shader 资产 ⇒ `Shader.Find("NonToon") == null`
//   （症状：材质洋红、探针 `ArgumentNullException: shader`）。注释只能写在本文件里。
//
// （C）**开关类属性用 `SC_float` 更稳** —— 但**不要**推广成"`SC_uint` 到不了 GPU"。
//
//   实测到的事实（2026-09-16 装置 C）：`_SelfLightRtPcss` 声明成 `SC_uint(...[SCToggle]...)` 时，
//   诊断通道读到 `R=(_SelfLightRtPcss>0.5)` 恒为 0.008（假），而同一材质/同一帧的
//   `_SelfLightRtBias`（`SC_float`）设置成功 ⇒ ⑥ 相位不执行。改成
//   `SC_float(..., [SCRange(0,1)], ...)` 后同一通道立刻变成 0.996。
//
//   ⛔ **但根因没有被证实，而且"SC_uint 的值到不了 GPU"这个推论几乎肯定是错的**，
//   证据三条（2026-09-17 复核）：
//     1. NonToon 里现有 **38 个** `SC_uint` 属性（`_RenderingMode`、`_UseSelfLight`、
//        各 `*MaskChannel`、`_EmissionBlendMode`、`_FurSubdivision` …），上游一直这么写；
//     2. `_UseSelfLight` 在运行期的 HLSL 里被直接比较（`if(_UseSelfLight && _SelfLightOnly<0.5)`），
//        而 ④「自有光」是**已发布、有探针守着的**功能 ⇒ 它要是永远读到 0，
//        ④ 对所有人都是坏的 —— 不成立；
//     3. `NonToon/Shaders/sc_common.hlsl` 的注释明写："引数を float で受けるのは、
//        SC_uint が生成する型（int/uint/float のいずれでも）を暗黙変換でそのまま…"
//        —— 作者们是在**正常使用** `SC_uint` 的前提下处理类型差异的。
//
//   ⇒ **留作独立的排查轮，别顺手去"修"那 38 个属性**（风险极大且大概率是白改）。
//     真要查就必须用**GPU 回读**（渲染到 RT 后读像素，像装置 C 那样），
//     不能用 `Material.GetFloat/GetInt` 之类的材质自省 —— 那测的是 CPU 侧缓存，
//     证明不了"没送到 GPU"。（另注：`NTGpuProbe` 证明**批处理下 RT 回读会全黑**，
//     所以这个测试得在能真渲染的上下文里做。）
Texture2D_float _NTRTShadowMapRaw;   // 我们自己的线性深度图（只读）

// ── 泊松盘 32 点（UnityPCSS 的公开常数表，MIT / Copyright (c) 2017 Lucas Norr，
//    已是 [-1,1] 圆盘内的单位分布）──────────────────────────────────────────────
static const float2 NTRTS_Poisson32[32] =
{
    float2( 0.06407013,  0.05409927), float2( 0.73665770,  0.57893940),
    float2(-0.62705420, -0.53202780), float2(-0.40961070,  0.84110950),
    float2( 0.68495640, -0.49908180), float2(-0.87418100, -0.04579735),
    float2( 0.99899980,  0.00098801), float2(-0.00492058, -0.91516490),
    float2( 0.18057630,  0.97474830), float2(-0.21384510,  0.26358180),
    float2( 0.10984500,  0.38847850), float2( 0.06876755, -0.35810740),
    float2( 0.37407300, -0.76612660), float2( 0.30791320, -0.12167630),
    float2(-0.37943350, -0.82715830), float2(-0.20387800, -0.07715034),
    float2( 0.59126970,  0.14697990), float2(-0.88069000,  0.30317840),
    float2( 0.50401080,  0.82837220), float2(-0.58441280,  0.38747840),
    float2( 0.32671980,  0.50512030), float2(-0.70485700,  0.38622860),
    float2( 0.55611110, -0.22286140), float2(-0.62876500,  0.73202480),
    float2( 0.33537080, -0.43105880), float2( 0.44076330, -0.71718210),
    float2(-0.29752930,  0.42821180), float2( 0.14525250,  0.69480790),
    float2( 0.74087380, -0.32837960), float2(-0.51509450, -0.24520310),
    float2( 0.39858960, -0.92907520), float2( 0.10355500,  0.75841130)
};

// ── 交错梯度噪声（Interleaved Gradient Noise，Jimenez 2014）──────────────────
// 为什么不用 `frac(sin(dot(p, float2(12.9898,78.233)))*43758.5453)`：
//   那个 hash 在 D3D11 的 half 精度路径上会出现明显的对角条纹，而且低比特位规律性强，
//   PCSS 的 per-pixel 旋转直接用它 ⇒ 画面出现**斜向的颗粒/条纹**（实机已看到噪点）。
//   IGN 只有 3 次乘加、频谱接近蓝噪声，是实时去带的标准做法。
float NTRTS_IGN(float2 p)
{
    return frac(52.9829189 * frac(dot(p, float2(0.06711056, 0.00583715))));
}

// 世界坐标 → 深度图 uv（0..1）。`r0..r3` 是 worldToShadow 的 4 行（由 phase 从属性传入）。
// 刻意**不用 `float4x4`**：4 行拆开做点积最省事，也避免任何矩阵类型带来的编译器差异。
// valid = 0 表示在光源背后（w <= 0），调用点应当直接跳过。
float2 NTRTS_ProjectUV(float4 r0, float4 r1, float4 r2, float4 r3, float3 wpos, out float valid)
{
    float4 p = float4(wpos, 1.0);
    float4 sc = float4(dot(r0, p), dot(r1, p), dot(r2, p), dot(r3, p));
    valid = sc.w > 1e-5 ? 1.0 : 0.0;
    return sc.xy / max(sc.w, 1e-6);
}

// ── 圆盘采样：Hammersley / Van der Corput 低差异序列 ─────────────────────────
// 为什么不用"固定泊松盘表 + 逐像素旋转"：
//   ① 表只有 32 个点，采样数一变就得复用/取子集，分布会退化；
//   ② 低差异序列（半径用 i/N 分层、角度用 radical inverse）在**同样采样数下**
//      比"随机旋转的泊松盘"方差更小 —— 这是降噪最直接的一步。
// （radical inverse 的位运算就是标准实现；随机旋转仍然保留，见 NTRTS_Rotate。）
float NTRTS_RadicalInverse(uint bits)
{
    bits = (bits << 16u) | (bits >> 16u);
    bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
    bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
    bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
    bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
    return float(bits) * 2.3283064365386963e-10;
}

// i ∈ [0, n)，返回单位圆盘内的点（面积均匀：r = sqrt(u)）
float2 NTRTS_DiscSample(int i, int n)
{
    float u = (float(i) + 0.5) / max((float)n, 1.0);
    float v = NTRTS_RadicalInverse((uint)i);
    float r = sqrt(u);
    float t = v * 6.2831853;
    float s, c;
    sincos(t, s, c);
    return float2(c, s) * r;
}

// 取我们自己的深度（0..1，越大越远）。
// 用 `Load`（整数像素）⇒ **不需要采样器**，避开 ShaderCore 里采样器绑不上的问题。
float NTRTS_RawDepth(float2 uv)
{
    uint w = 1u, h = 1u;
    _NTRTShadowMapRaw.GetDimensions(w, h);
    if (w < 1u) w = 1u;
    if (h < 1u) h = 1u;
    int2 px = int2(uv * float2((float)w, (float)h));
    px = clamp(px, int2(0, 0), int2((int)w - 1, (int)h - 1));
    return _NTRTShadowMapRaw.Load(int3(px, 0)).r;
}

// 单点阴影判定：1 = 受光。记为阴影 ⇔ 深度图里的遮挡深度 + bias < 本片元深度
float NTRTS_LitRaw(float2 uv, float fragDepth, float bias)
{
    float d = NTRTS_RawDepth(uv);
    return d + bias >= fragDepth ? 1.0 : 0.0;
}

// ── PCSS：blocker 搜索 → 半影估计 → 变半径滤波 ────────────────────────────────
//   uv        : 深度图 uv（0..1）
//   fragDepth : 本片元在同一线性尺度下的深度（0..1，越大越远）
//   rnd       : 每像素随机数（去带 + 旋转），来自 NTRTS_IGN
//   texels    : 深度图边长；bias : 归一化深度；softness / lightSize / quality : 材质属性
//
// ⚠️ 采样数为什么按 `(i*32)/n` 跨表取，而不是 `i % 32`：
//   `i % 32` 在 n < 32 时只用到泊松表的**前 n 个点** —— 那 n 个点集中在圆盘的一侧，
//   所以"8 个样本"实际覆盖的立体角很小 ⇒ 半影里出现**块状/条纹**而不是均匀噪声。
//   跨表取（`(i*32)/n`）保证任意 n 都在整个圆盘上均匀铺开，是噪点明显更小的一步。
float NTRTS_PCSS(float2 uv, float fragDepth, float rnd,
                 float texels, float bias, float softness, float lightSize, float quality,
                 float shadowFloor)
{
    texels = max(texels, 8.0);
    float texel = 1.0 / texels;
    // 纹素半径的世界尺度 ∝ 分辨率 ⇒ 乘 resScale 让"世界半影"与分辨率无关（烘焙版 P2 的教训）
    float resScale = texels / 512.0;
    float lightSizeTexels = max(lightSize, 0.0) * max(softness, 0.0) * resScale;

    float ang = rnd * 6.2831853;
    float ca = cos(ang), sa = sin(ang);

    int q = (int)quality;
    int nBlocker = q < 1 ? 8 : (q < 2 ? 12 : (q < 3 ? 16 : 24));

    // blocker 搜索半径：与"虚拟灯尺寸"挂钩。**必须比 1 纹素大得多** ——
    // 遮挡物的深度图足迹本身有几十纹素，搜索半径太小就永远搜不到遮挡物。
    float searchTexels = clamp(lightSizeTexels * 2.0, 12.0, texels * 0.2);
    float searchR = searchTexels * texel;

    // ---- 1) blocker 搜索：取"比本片元更近"的平均深度 ----
    float blockerSum = 0.0;
    float blockerCnt = 0.0;
    for (int i = 0; i < nBlocker; i++)
    {
        float2 sd = NTRTS_DiscSample(i, nBlocker);
        float2 o = float2(sd.x * ca - sd.y * sa, sd.x * sa + sd.y * ca) * searchR;
        float d = NTRTS_RawDepth(uv + o);
        if (d < fragDepth - bias)
        {
            blockerSum += d;
            blockerCnt += 1.0;
        }
    }
    // ⛔ 全遮挡 ⇒ **直接返回 0，完全不滤波**。
    //    学自 PCSS4VRC 的 `if (blockerInfo.y == Blocker_Samples) return 0;`：
    //    本影里滤波没有任何意义，只会把"边缘附近偶尔有一个采样落到受光侧"的
    //    随机跳动放大成**本影里的颗粒**。这是他们实现里最有效的一条降噪。
    if (blockerCnt >= (float)nBlocker - 0.5) return shadowFloor;
    if (blockerCnt < 0.5) return 1.0;        // 附近没有遮挡物 ⇒ 完全受光（同样是早退）

    // ---- 2) 半影估计 ----
    float avgBlocker = blockerSum / blockerCnt;
    float penumbraRatio = max(0.0, fragDepth - avgBlocker) / max(avgBlocker, 1e-4);

    // 半径 = **下限 + 平滑项**（学 PCSS4VRC 的 `Softness + searchSize*lerp(...)` 结构）。
    // ⚠️ 为什么不能直接用 `penumbraRatio * lightSizeTexels`：`avgBlocker` 是若干个
    //    0/1 判定的平均，相邻像素间会跳变 ⇒ **半径噪声**。半径一跳，整个取样核就跳，
    //    看起来比"0/1 噪声"更刺眼（成片的斑块而不是细颗粒）。
    //    这里让半径至少是 `0.25 * lightSizeTexels`，并把变化项压到 0..1 再乘 0.75，
    //    于是半径随半影单调增长、但抖动被限制在半倍以内。
    // 半径 = lightSizeTexels * (小下限 + 1.3 * 比率)。
    // 下限（10%）只负责"核永远不小于 ~3 纹素、不至于退化成硬边+颗粒"，
    // 主项仍是**比值式**，所以"遮挡物越远半影越宽"这条物理性质完整保留（动态范围约 9 倍）。
    float radiusTexels = clamp(lightSizeTexels * (0.10 + 1.15 * penumbraRatio), 1.5, texels * 0.25);
    float penumbraNorm = saturate(radiusTexels / max(lightSizeTexels, 1e-3) * 0.6);
    float radius = radiusTexels * texel;

    // ---- 3) 变半径滤波：**采样数自适应**（学它的 `lerp(4, PCF_Samples, saturate(penumbra/…))`）
    //   半影越宽 → 用越多采样（最多 64）⇒ 把预算花在真正看得到过渡的地方。
    // 滤波采样数 = **质量档给的上下限** × **按半影自适应**（两个都保留：
    // 质量档决定预算，半影决定把预算花在哪 —— 这就是 PCSS4VRC 的
    // `lerp(4, PCF_Samples, saturate(penumbra/…))` 结构，只是下限也随档位走）。
    float minF = q < 1 ? 8.0  : (q < 2 ? 12.0 : (q < 3 ? 16.0 : 24.0));
    float maxF = q < 1 ? 24.0 : (q < 2 ? 32.0 : (q < 3 ? 48.0 : 64.0));
    int nFilter = (int)clamp(minF + (maxF - minF) * penumbraNorm, minF, maxF);
    float sum = 0.0;
    for (int j = 0; j < nFilter; j++)
    {
        float2 sd = NTRTS_DiscSample(j, nFilter);
        float2 o = float2(sd.x * ca - sd.y * sa, sd.x * sa + sd.y * ca) * radius;
        sum += NTRTS_LitRaw(uv + o, fragDepth, bias);
    }
    // /**阴影下限**：完全遮蔽处不返回 0，而是返回 `shadowFloor`。
    // 为什么必须在这里做：NonToon 随后会 `clamp(env + lightSum.color, _LightMinLimit, _LightMaxLimit)`，
    // 而 `_LightMinLimit` 默认 0 ⇒ 没有环境光时**整个模型会变成纯黑**（用户实测反馈）。
    // 下限让"最暗处仍保留一点灯色"，观感上是"阴影里的环境反射"，而不是黑洞。
    float lit = sum / (float)nFilter;
    return lerp(shadowFloor, 1.0, lit);
}
#endif

// ---------------------------------------------------------------------------
// [NT-FEAT 16] 色温（Kelvin）→ RGB。
// Tanner Helland 的黑体辐射近似：几行 ALU、零采样。6500K ≈ 白，低色温偏橙、高色温偏蓝。
// 用法：NT_SELFLIGHT_KELVIN(outRGB, kelvin)
// ---------------------------------------------------------------------------
#ifndef NT_SELFLIGHT_KELVIN
#define NT_SELFLIGHT_KELVIN(outRGB, kelvin) \
{ \
    float ntSK_T = clamp((kelvin), 1000.0, 40000.0) / 100.0; \
    float ntSK_R = ntSK_T <= 66.0 ? 255.0 : 329.698727446 * pow(max(ntSK_T - 60.0, 1e-3), -0.1332047592); \
    float ntSK_G = ntSK_T <= 66.0 ? (99.4708025861 * log(max(ntSK_T, 1.0)) - 161.1195681661) : (288.1221695283 * pow(max(ntSK_T - 60.0, 1e-3), -0.0755148492)); \
    float ntSK_B = ntSK_T >= 66.0 ? 255.0 : (ntSK_T <= 19.0 ? 0.0 : (138.5177312231 * log(max(ntSK_T - 10.0, 1e-3)) - 305.0447927307)); \
    outRGB = saturate(half3(ntSK_R, ntSK_G, ntSK_B) / 255.0); \
}
#endif

// ---------------------------------------------------------------------------
// [NT-FEAT 17] 世界光的颜色（"探地图的灯"用）。
// 取 SH 的 L0 项（环境光的颜色）；光照贴图工程里 SH 不可用，就退化成主光颜色。
// 用法：NTSELFLIGHT_WORLD_COLOR(outWorld, ambientColor)
//   ambientColor 由调用点算 —— 宏体里不能放 #if 之类的预处理指令
// ---------------------------------------------------------------------------
#ifndef NTSELFLIGHT_WORLD_COLOR
#define NTSELFLIGHT_WORLD_COLOR(outWorld, ambientColor)\
{\
    outWorld = (ambientColor) + _LightColor0.rgb * 0.5;\
}
#endif

// ---------------------------------------------------------------------------
// [NT-FEAT 17] 自有光的最终颜色：色温 → 环境匹配。
// 用法：NTSELFLIGHT_COLOR(outColor, ambientColor)
// ---------------------------------------------------------------------------
#ifndef NTSELFLIGHT_COLOR
#define NTSELFLIGHT_COLOR(outColor, ambientColor) \
{ \
    half3 ntSLC_Base = _SelfLightColor.rgb; \
    if (_SelfLightUseTemperature > 0.001) \
    { \
        half3 ntSLC_Kelvin; \
        NT_SELFLIGHT_KELVIN(ntSLC_Kelvin, _SelfLightTemperature) \
        ntSLC_Base *= ntSLC_Kelvin; \
    } \
    outColor = ntSLC_Base; \
    if (_SelfLightMatchAmbient > 0.001) \
    { \
        half3 ntSLC_World = (ambientColor); \
        outColor = lerp(ntSLC_Base, ntSLC_World, saturate(_SelfLightMatchAmbient)); \
    } \
}
#endif

// ---------------------------------------------------------------------------
// [NT-FEAT 17] 自有光的方向：可选跟随"世界主光"的方向，
// 这样自带阴影的落向与地图里的太阳一致，不会看起来像贴上去的。
// 只在 base pass 有效（附加光 pass 里 _WorldSpaceLightPos0 指的是那盏附加光）。
// 用法：NTSELFLIGHT_DIR(outDir, positionWS)
// ---------------------------------------------------------------------------
#ifndef NTSELFLIGHT_DIR
#define NTSELFLIGHT_DIR(outDir, positionWS) \
{ \
    half3 ntSLD_Self = _SelfLightDirection.xyz; \
    ntSLD_Self = dot(ntSLD_Self, ntSLD_Self) > 0 ? normalize(ntSLD_Self) : half3(0, 1, 0); \
    if (_SelfLightMatchDirection > 0.001) \
    { \
        half3 ntSLD_World = _WorldSpaceLightPos0.w == 0 \
            ? normalize(_WorldSpaceLightPos0.xyz) \
            : normalize(_WorldSpaceLightPos0.xyz - (positionWS)); \
        ntSLD_Self = normalize(lerp(ntSLD_Self, ntSLD_World, saturate(_SelfLightMatchDirection))); \
    } \
    outDir = ntSLD_Self; \
}
#endif

#endif
