using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace NonToonTools
{
    // [NT-FEAT 20] 生成「游戏内可调的光照强度」所需的资产。
    //
    // ── 为什么不能用运行时脚本 ──────────────────────────────────────────────
    // VRChat 官方文档《Allowed Avatar Components》明确写着：
    //   "Any component on the following list can be used in VRChat.
    //    Other components or custom scripts won't work in VRChat and may stop you from uploading your avatar."
    // 白名单里只有 Animator / Animation / Light / Renderer 这类，**没有自定义脚本**。
    // 所以"玩家在游戏里拉一下就把自己调亮"只能靠：
    //   Animator 的 Float 参数（由 Expression Menu 的 Radial Puppet 控制，值域 0.0–1.0）
    //   → BlendTree 在两条 AnimationClip 之间混合
    //   → AnimationClip 直接给 renderer 的 material 属性打曲线（material._SelfLightIntensity）
    // 全都是白名单内的东西，Quest 也能用，且**不需要往 avatar 上挂我们自己的脚本**。
    //
    // ── 为什么全走反射 ──────────────────────────────────────────────────────
    // 本包坚持零 VRCSDK 依赖（没装 SDK 的人也能用着色器与转换器）。
    // 所以这里只按类型名/字段名去找 VRC 的类型，找不到就退回"打印手动步骤"。
    //
    // 参数代价（官方文档）：Float = 8 bit 同步内存；VRChat 最多 256 bit 自定义同步参数。
    internal static class NTVrcParameterBuilder
    {
        internal sealed class Result
        {
            public readonly List<string> Done = new List<string>();
            public readonly List<string> Manual = new List<string>();
            public readonly List<string> Errors = new List<string>();
            public bool Ok { get { return Errors.Count == 0; } }
            public string Summary()
            {
                var sb = new System.Text.StringBuilder();
                foreach (var s in Done) sb.AppendLine("  ✅ " + s);
                foreach (var s in Manual) sb.AppendLine("  ⚠️ 需要手动：" + s);
                foreach (var s in Errors) sb.AppendLine("  ❌ " + s);
                return sb.ToString();
            }
        }

        internal const string DefaultFolder = "Assets/NonToonLightAdjuster";
        internal const string LayerPrefix = "NonToon ";
        // 默认驱动「亮度下限」——这是 LLC（LightLimitChanger）那一系的思路：
        //   NonToon 与 lilToon 的亮度公式完全一致：RGB = clamp(RGB, _LightMinLimit, _LightMaxLimit)
        //   而 NonToon 的 _LightMinLimit **默认是 0**，所以全黑地图里就是一块煤。
        //   把它抬高（lilToon 官方建议 VRChat 里 0.0~0.2）就能防煤，且**零采样代价、不必开自有光**。
        internal const string DefaultProp = "_LightMinLimit";

        // ---------------------------------------------------------------- 反射工具
        private static Type FindType(params string[] fullNames)
        {
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                foreach (var n in fullNames)
                {
                    var t = asm.GetType(n, false);
                    if (t != null) return t;
                }
            return null;
        }

        private static object ParseEnum(Type enumType, string name)
        {
            if (enumType == null) return null;
            try { return Enum.Parse(enumType, name, true); } catch { return null; }
        }

        private static FieldInfo F(Type t, string n)
        {
            return t?.GetField(n, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        }
        private static object Get(object o, string n) { return F(o?.GetType(), n)?.GetValue(o); }
        private static void Set(object o, string n, object v)
        {
            var f = F(o?.GetType(), n);
            if (f == null) throw new MissingFieldException((o?.GetType().Name ?? "null") + "." + n);
            f.SetValue(o, v);
        }

        // ---------------------------------------------------------------- 主流程
        internal static Result Build(
            GameObject avatarRoot,
            List<Renderer> renderers,
            string paramName,
            float intensityAtZero,
            float intensityAtOne,
            bool synced,
            bool createMenu,
            string folder,
            string propName = null)
        {
            var r = new Result();
            if (avatarRoot == null) { r.Errors.Add("没有指定 avatar 根节点"); return r; }
            if (renderers == null || renderers.Count == 0) { r.Errors.Add("没有找到可用于动画的 Renderer"); return r; }
            if (string.IsNullOrEmpty(paramName)) { r.Errors.Add("参数名不能为空"); return r; }
            if (string.IsNullOrEmpty(folder)) folder = DefaultFolder;
            if (string.IsNullOrEmpty(propName)) propName = DefaultProp;
            EnsureFolder(folder);

            // 1) Animator 参数 + 两条曲线剪辑 + 一层 BlendTree
            BuildAnimator(avatarRoot, renderers, paramName, intensityAtZero, intensityAtOne, folder, propName, r);

            // 2) VRC Expression Parameter（Float，0–1 由径向菜单给）
            var descType = FindType("VRC.SDK3.Avatars.Components.VRCAvatarDescriptor", "VRC_AvatarDescriptor");
            if (descType == null)
            {
                r.Manual.Add("没检测到 VRCSDK：请在 Project 里手动新建一个 Float 参数 " + paramName +
                             "（-1~1），加到 VRC Expression Parameters（Float、默认 0、可勾「保存」），" +
                             "并在 Expression Menu 里加一个 Radial Puppet 指向它");
            }
            else
            {
                var desc = avatarRoot.GetComponent(descType);
                if (desc == null)
                {
                    r.Manual.Add("根节点上没有 VRCAvatarDescriptor：请先把它设为 avatar（SDK 面板里 Create Avatar Descriptor）");
                }
                else
                {
                    if (!EnsureExpressionParameter(desc, paramName, synced, r))
                        r.Manual.Add("在 VRC Expression Parameters 里手动加一个 Float 参数 " + paramName +
                                     "（默认 0" + (synced ? "、勾「同步」" : "、不要同步") + "，占 8 bit）");
                    BuildFxLayerAssignment(desc, r);
                    if (createMenu)
                    {
                        if (!EnsureRadialMenu(desc, paramName, r))
                            r.Manual.Add("在 Expression Menu 里手动加一个 Radial Puppet，参数选 " + paramName +
                                         "（每个菜单最多 8 项，满了就用子菜单）");
                    }
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            return r;
        }

        private static void EnsureFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return;
            var parent = Path.GetDirectoryName(folder).Replace('\\', '/');
            var leaf = Path.GetFileName(folder);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
            AssetDatabase.CreateFolder(string.IsNullOrEmpty(parent) ? "Assets" : parent, leaf);
        }

        // ---------------------------------------------------------------- Animator
        private static void BuildAnimator(
            GameObject avatarRoot, List<Renderer> renderers, string paramName,
            float atZero, float atOne, string folder, string propName, Result r)
        {
            var tag = propName.TrimStart('_');
            var layerName = LayerPrefix + tag;
            // ⚠️ AnimationClip 资产必须用 .anim 扩展名：用 .clip 时 Unity 会拒绝创建
            // （日志：CreateAsset() should not be used to create a file of type 'clip'）—— 实测踩过。
            var lowPath = folder + "/" + Sanitize(paramName) + "_" + tag + "_低.anim";
            var highPath = folder + "/" + Sanitize(paramName) + "_" + tag + "_高.anim";

            var low = CreatePropClip(lowPath, avatarRoot, renderers, atZero, propName);
            var high = CreatePropClip(highPath, avatarRoot, renderers, atOne, propName);
            if (low == null || high == null) { r.Errors.Add("创建 AnimationClip 失败"); return; }
            r.Done.Add("生成曲线剪辑：" + Path.GetFileName(lowPath) + "（" + propName + " = " + atZero + "）、"
                       + Path.GetFileName(highPath) + "（" + atOne + "），绑定 "
                       + renderers.Count + " 个 Renderer 的 material." + propName);

            // FX 控制器：优先用 avatar 已有的，找不到就新建一个
            var descType = FindType("VRC.SDK3.Avatars.Components.VRCAvatarDescriptor");
            AnimatorController fx = null;
            if (descType != null)
            {
                var desc = avatarRoot.GetComponent(descType);
                fx = GetFxController(desc);
            }
            if (fx == null)
            {
                var fxPath = folder + "/NonToonLightAdjusterFX.controller";
                if (File.Exists(fxPath)) AssetDatabase.DeleteAsset(fxPath);
                fx = AnimatorController.CreateAnimatorControllerAtPath(fxPath);
                r.Done.Add("新建 FX AnimatorController：" + fxPath + "（记得在 avatar 的 FX 层指向它，或直接用 SDK 面板检查）");
            }

            // Float 参数（没有才加）
            if (!fx.parameters.Any(p => p.name == paramName))
            {
                fx.AddParameter(paramName, AnimatorControllerParameterType.Float);
                r.Done.Add("Animator 参数 +Float " + paramName);
            }
            else r.Done.Add("Animator 参数 " + paramName + " 已存在（复用）");

            // 生成用的层：同名先删（保证可重复运行）
            for (int i = fx.layers.Length - 1; i >= 0; i--)
                if (fx.layers[i].name == layerName) fx.RemoveLayer(i);

            fx.AddLayer(layerName);
            var layer = fx.layers[fx.layers.Length - 1];
            var sm = layer.stateMachine;
            var bt = new BlendTree
            {
                name = paramName + "_blend",
                blendType = BlendTreeType.Simple1D,
                blendParameter = paramName,
                useAutomaticThresholds = false,
            };
            AssetDatabase.AddObjectToAsset(bt, fx);
            bt.AddChild(low, 0f);
            bt.AddChild(high, 1f);

            var st = sm.AddState("亮度");
            st.motion = bt;
            st.writeDefaultValues = false;
            sm.defaultState = st;
            EditorUtility.SetDirty(fx);
            r.Done.Add("新增 Animator 层「" + layerName + "」：BlendTree 按 " + paramName + " 在两条曲线间混合（0 → "
                       + atZero + "，1 → " + atOne + "）");
        }

        private static AnimationClip CreatePropClip(string path, GameObject root, List<Renderer> renderers, float value, string propName)
        {
            if (File.Exists(path)) AssetDatabase.DeleteAsset(path);
            var clip = new AnimationClip { frameRate = 60f, legacy = false };
            var curve = AnimationCurve.Constant(0f, 1f / 60f, value);
            foreach (var rd in renderers)
            {
                if (rd == null) continue;
                // material.<属性名> 曲线：这是 VRChat 支持的材质属性动画写法
                var rel = AnimationUtility.CalculateTransformPath(rd.transform, root.transform);
                var binding = EditorCurveBinding.FloatCurve(rel, rd.GetType(), "material." + propName);
                AnimationUtility.SetEditorCurve(clip, binding, curve);
            }
            AssetDatabase.CreateAsset(clip, path);
            return AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
        }

        private static string Sanitize(string s)
        {
            foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s;
        }

        // FX 层：descriptor.baseAnimationLayers 里 type == FX 的那条
        private static AnimatorController GetFxController(object descriptor)
        {
            if (descriptor == null) return null;
            var f = F(descriptor.GetType(), "baseAnimationLayers");
            var arr = f?.GetValue(descriptor) as Array;
            if (arr == null) return null;
            foreach (var item in arr)
            {
                if (item == null) continue;
                var t = Get(item, "type");
                if (t == null || !t.ToString().Equals("FX", StringComparison.OrdinalIgnoreCase)) continue;
                var c = Get(item, "animatorController") as AnimatorController;
                if (c == null)
                {
                    var ovr = Get(item, "animatorController") as AnimatorOverrideController;
                    if (ovr != null) c = ovr.runtimeAnimatorController as AnimatorController;
                }
                if (c != null) return c;
            }
            return null;
        }

        private static void BuildFxLayerAssignment(object descriptor, Result r)
        {
            // 只有在 avatar 已开启自定义动画层时才需要提示；否则 SDK 面板里也能指
            var customize = Get(descriptor, "customizeAnimationLayers");
            if (customize is bool b && !b)
                r.Manual.Add("在 avatar 的「Animator」面板勾上 Customize Animation Layers（否则你新建的 FX 控制器不会被使用）");
        }

        // ---------------------------------------------------------------- Expression Parameter
        private static bool EnsureExpressionParameter(object descriptor, string paramName, bool synced, Result r)
        {
            try
            {
                var paramType = FindType("VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionParameters");
                var valueTypeEnum = paramType?.GetNestedType("ValueType", BindingFlags.Public);
                if (paramType == null || valueTypeEnum == null) return false;

                var ps = F(descriptor.GetType(), "expressionParameters")?.GetValue(descriptor);
                if (ps == null)
                {
                    var path = DefaultFolder + "/VRCExpressionParameters.asset";
                    if (File.Exists(path)) AssetDatabase.DeleteAsset(path);
                    ps = ScriptableObject.CreateInstance(paramType);
                    AssetDatabase.CreateAsset((UnityEngine.Object)ps, path);
                    Set(descriptor, "expressionParameters", ps);
                    r.Done.Add("新建 VRCExpressionParameters：" + path);
                }

                var pf = F(paramType, "parameters");
                var arr = pf?.GetValue(ps) as Array;
                if (arr == null) { arr = Array.CreateInstance(pf.FieldType.GetElementType(), 0); }
                var elemType = pf.FieldType.GetElementType();

                // 已存在就只更新同步位
                foreach (var e in arr)
                {
                    if (e != null && (string)Get(e, "name") == paramName)
                    {
                        var sField = F(elemType, "saved");
                        if (sField != null) sField.SetValue(e, synced);
                        pf.SetValue(ps, arr);
                        EditorUtility.SetDirty((UnityEngine.Object)ps);
                        r.Done.Add("Expression Parameter " + paramName + " 已存在（同步=" + synced + "，占 "
                                   + (synced ? 8 : 0) + " bit）");
                        return true;
                    }
                }

                // 追加
                var ne = Activator.CreateInstance(elemType);
                Set(ne, "name", paramName);
                F(elemType, "valueType")?.SetValue(ne, ParseEnum(valueTypeEnum, "Float"));
                F(elemType, "defaultValue")?.SetValue(ne, 0f);
                F(elemType, "saved")?.SetValue(ne, synced);

                var bigger = Array.CreateInstance(elemType, arr.Length + 1);
                Array.Copy(arr, bigger, arr.Length);
                bigger.SetValue(ne, arr.Length);
                pf.SetValue(ps, bigger);
                EditorUtility.SetDirty((UnityEngine.Object)ps);
                r.Done.Add("Expression Parameter +" + paramName + "（Float、默认 0、同步=" + synced + "，占 "
                           + (synced ? 8 : 0) + " bit 同步内存）");
                return true;
            }
            catch (Exception e)
            {
                r.Errors.Add("写 Expression Parameter 失败：" + e.Message);
                return false;
            }
        }

        // ---------------------------------------------------------------- Expressions Menu
        private static bool EnsureRadialMenu(object descriptor, string paramName, Result r)
        {
            try
            {
                var menuType = FindType("VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu");
                var ctrlType = menuType?.GetNestedType("Control", BindingFlags.Public);
                var ctrlTypeEnum = ctrlType?.GetNestedType("ControlType", BindingFlags.Public);
                var ctrlParamType = menuType?.GetNestedType("Parameter", BindingFlags.Public)
                                    ?? ctrlType?.GetNestedType("Parameter", BindingFlags.Public);
                if (menuType == null || ctrlType == null || ctrlTypeEnum == null) return false;

                var menu = F(descriptor.GetType(), "expressionsMenu")?.GetValue(descriptor);
                if (menu == null)
                {
                    var path = DefaultFolder + "/VRCExpressionsMenu.asset";
                    if (File.Exists(path)) AssetDatabase.DeleteAsset(path);
                    menu = ScriptableObject.CreateInstance(menuType);
                    AssetDatabase.CreateAsset((UnityEngine.Object)menu, path);
                    Set(descriptor, "expressionsMenu", menu);
                    r.Done.Add("新建 VRCExpressionsMenu：" + path);
                }

                var listField = F(menuType, "controls");
                var list = listField.GetValue(menu) as System.Collections.IList;
                if (list == null) return false;

                // 已有同参数控件就不重复加
                foreach (var c in list)
                {
                    var p = c == null ? null : Get(c, "parameter");
                    if (p != null && (string)Get(p, "name") == paramName)
                    {
                        r.Done.Add("菜单已有指向 " + paramName + " 的控件（复用）");
                        return true;
                    }
                }

                // VRChat 每个菜单最多 8 项
                var target = menu;
                if (list.Count >= 8)
                {
                    object sub = null;
                    foreach (var c in list)
                    {
                        var ct = Get(c, "type")?.ToString();
                        var nm = (string)Get(c, "name");
                        if (ct != null && ct.Equals("SubMenu", StringComparison.OrdinalIgnoreCase) && nm == "NonToon 光照")
                        { sub = Get(c, "subMenu"); break; }
                    }
                    if (sub == null) return false;   // 菜单满了，交给手动步骤
                    target = sub;
                    list = F(menuType, "controls").GetValue(target) as System.Collections.IList;
                }

                var nc = Activator.CreateInstance(ctrlType);
                Set(nc, "name", "光照强度");
                F(ctrlType, "type")?.SetValue(nc, ParseEnum(ctrlTypeEnum, "RadialPuppet"));
                if (ctrlParamType != null)
                {
                    var cp = Activator.CreateInstance(ctrlParamType);
                    Set(cp, "name", paramName);
                    F(ctrlType, "parameter")?.SetValue(nc, cp);
                }
                list.Add(nc);
                EditorUtility.SetDirty((UnityEngine.Object)target);
                r.Done.Add("Expression Menu +「光照强度」Radial Puppet → " + paramName + "（拉到 0=最暗、1=最亮）");
                return true;
            }
            catch (Exception e)
            {
                r.Errors.Add("写 Expressions Menu 失败：" + e.Message);
                return false;
            }
        }
    }
}
